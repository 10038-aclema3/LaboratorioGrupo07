<?php
  define("SERVER","10.40.48.248");
  define("USER","root");
  define("PASS","test");
  define("BD","Veris");

  
  define("PATH","imagenes/usuarios");

 ?>