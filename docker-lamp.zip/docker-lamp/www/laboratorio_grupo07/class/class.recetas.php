<?php
class receta
{
	private $IdReceta;
	private $IdConsulta;
	private $IdMedicamento;
	private $Cantidad;
	private $MedicoID;
	private $IdPaciente;
	private $Diagnostico;
	private $con;

	function __construct($cn)
	{
		$this->con = $cn;
	}


	//*********************** 3.1 METODO update_receta() **************************************************	

	public function update_receta()
	{
		$this->IdReceta = $_POST['IdReceta'];
		$this->IdConsulta = $_POST['IdConsulta'];
		$this->IdMedicamento = $_POST['IdMedicamento'];
		$this->Cantidad = $_POST['Cantidad'];


		$sql = "UPDATE recetas SET IdConsulta='$this->IdConsulta',
									IdMedicamento='$this->IdMedicamento',
									Cantidad='$this->Cantidad'
				WHERE IdReceta='$this->IdReceta';";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("modificó");
		} else {
			echo $this->_message_error("al modificar");
		}
	}


	//*********************** 3.2 METODO save_receta() **************************************************	

	public function save_receta()
	{

		$this->IdConsulta = $_POST['IdConsulta'];
		$this->IdMedicamento = $_POST['IdMedicamento'];
		$this->Cantidad = $_POST['Cantidad'];
		
		
		$sql = "INSERT INTO recetas (`IdConsulta`, `IdMedicamento`, `Cantidad`) VALUES(
											'$this->IdConsulta',
											'$this->IdMedicamento',
											'$this->Cantidad');";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("guardó");
		} else {
			echo $this->_message_error("guardar");
		}
	}


	//*********************** 3.3 METODO _get_name_File() **************************************************	

	private function _get_name_file($nombre_original, $tamanio)
	{
		$tmp = explode(".", $nombre_original); //Divido el nombre por el punto y guardo en un arreglo
		$numElm = count($tmp); //cuento el número de elemetos del arreglo
		$ext = $tmp[$numElm - 1]; //Extraer la última posición del arreglo.
		$cadena = "";
		for ($i = 1; $i <= $tamanio; $i++) {
			$c = rand(65, 122);
			if (($c >= 91) && ($c <= 96)) {
				$c = NULL;
				$i--;
			} else {
				$cadena .= chr($c);
			}
		}
		return $cadena . "." . $ext;
	}


	//*************************************** PARTE I ************************************************************


	/*Aquí se agregó el parámetro:  $defecto*/
	private function _get_combo_db($tabla, $valor, $etiqueta, $nombre, $defecto)
	{
		$html = '<select name="' . $nombre . '">';
		$sql = "SELECT $valor,$etiqueta FROM $tabla;";
		$res = $this->con->query($sql);
		while ($row = $res->fetch_assoc()) {
			//ImpResultQuery($row);
			$html .= ($defecto == $row[$valor]) ? '<option value="' . $row[$valor] . '" selected>' . $row[$etiqueta] . '</option>' . "\n" : '<option value="' . $row[$valor] . '">' . $row[$etiqueta] . '</option>' . "\n";
		}
		$html .= '</select>';
		return $html;
	}

	/*Aquí se agregó el parámetro:  $defecto*/
	private function _get_combo_anio($nombre, $anio_inicial, $defecto)
	{
		$html = '<select name="' . $nombre . '">';
		$anio_actual = date('Y');
		for ($i = $anio_inicial; $i <= $anio_actual; $i++) {
			$html .= ($i == $defecto) ? '<option value="' . $i . '" selected>' . $i . '</option>' . "\n" : '<option value="' . $i . '">' . $i . '</option>' . "\n";
		}
		$html .= '</select>';
		return $html;
	}

	/*Aquí se agregó el parámetro:  $defecto*/
	private function _get_radio($arreglo, $nombre, $defecto)
	{

		$html = '
		<table border=0 align="left">';

		//CODIGO NECESARIO EN CASO QUE EL USUARIO NO SE ESCOJA UNA OPCION

		foreach ($arreglo as $etiqueta) {
			$html .= '
			<tr>
				<td>' . $etiqueta . '</td>
				<td>';

			if ($defecto == NULL) {
				// OPCION PARA GRABAR UN NUEVA RECETA (id=0)
				$html .= '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>';
			} else {
				// OPCION PARA MODIFICAR UN RECETA EXISTENTE
				$html .= ($defecto == $etiqueta) ? '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>' : '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '"/></td>';
			}

			$html .= '</tr>';
		}
		$html .= '
		</table>';
		return $html;
	}


	//************************************* PARTE II ****************************************************	

	public function get_form($id = NULL)
	{

		if ($id == NULL) {
			$this->IdConsulta = NULL;
			$this->IdMedicamento = NULL;
			$this->Cantidad = NULL;

			$flag = NULL;
			$op = "new";
		} else {

			$sql = "SELECT r.IdReceta, r.IdConsulta, c.IdPaciente,  c.IdMedico, r.IdMedicamento, r.Cantidad
			FROM recetas as r 
			JOIN consultas as c ON r.IdConsulta = c.IdConsulta 
			JOIN medicamentos as m ON r.IdMedicamento = m.IdMedicamento 
			JOIN medicos as md ON c.IdMedico = md.IdMedico 
			JOIN pacientes as p ON c.IdPaciente = p.IdPaciente 
			WHERE r.IdReceta = $id;";
			$res = $this->con->query($sql);
			$row = $res->fetch_assoc();

			$num = $res->num_rows;
			if ($num == 0) {
				$mensaje = "tratar de actualizar la receta con id= " . $id;
				echo $this->_message_error($mensaje);
			} else {

				// ***** TUPLA ENCONTRADA *****
				echo "<br>TUPLA <br>";
				echo "<pre>";
				print_r($row);
				echo "</pre>";

				$this->IdConsulta = $row['IdConsulta'];
				$this->IdPaciente = $row['IdPaciente'];
				$this->IdMedicamento = $row['IdMedicamento'];
				$this->Cantidad = $row['Cantidad'];

				$flag = "disabled";
				$op = "update";
			}
		}


		$html = '
		<form name="receta" method="POST" action="recetas.php" enctype="multipart/form-data">
		
		<input type="hidden" name="IdReceta" value="' . $id  . '">
		<input type="hidden" name="IdConsulta" value="' . $this->IdConsulta  . '">
		<input type="hidden" name="op" value="' . $op  . '">
		
  		<table border="1" align="center">
				<tr>
					<th colspan="2">DATOS PARA LA RECETA</th>
				</tr>
				<tr>
					<td>Paciente:</td>
					<td>' . $this->_get_combo_db("pacientes", "IdPaciente", "Nombre", "IdPaciente", $this->IdPaciente) . '</td>
				</tr>
				<tr>
					<td>Consultas:</td>
					<td>' . $this->_get_combo_db("consultas", "IdConsulta", "Diagnostico", "IdConsulta", $this->IdConsulta) . '</td>
				<tr>
					<td>Medicamento:</td>
					<td>' . $this->_get_combo_db("medicamentos", "IdMedicamento", "Nombre", "IdMedicamento", $this->IdMedicamento) . '</td>
				</tr>
				<tr>
					<td>Cantidad:</td>
					<td><input type="text" name="Cantidad" value="' . $this->Cantidad . '"></td>
				</tr>
					<th colspan="2"><input type="submit" name="Guardar" value="GUARDAR"></th>
                    <th colspan="3"><a class="btn btn-danger" href="recetas.php" role="button">Cancelar</a></th>
				</tr>												
			</table>';
		return $html;
	}

	public function get_menu(){
        $menuHtml = '<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<img src="../front/Recursos/selloespe.jpg" alt="" height="50px" width="90px">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item ">
					<a class="nav-link" href="consultas.php">Consultas</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Pacientes</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Medicos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Medicamentos</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="recetas.php">Recetas</a>
				</li>
				<li class="nav-item">
                    <a class="nav-link" href="logout.php">Cerrar Sesión</a> 
				</li>
			</ul>
		</div>
	</nav>';

    return $menuHtml;
    }

	public function get_list()
	{
		$d_new = "new/0";
		$d_new_final = base64_encode($d_new);
		$html = '
		<div class="container">
			<table class="table table-bordered table-striped table-dark mx-auto text-center my-5">
				<thead class="thead-dark">
					<tr>
						<th colspan="8" class="align-middle">Lista de Recetas</th>
					</tr>
					<tr>
						<th colspan="8"><a class="btn btn-warning" href="recetas.php?d=' . $d_new_final . '" role="button">Nuevo</a></th>
						
					</tr>
					<tr>
						<th class="align-middle">NombrePaciente</th>
						<th class="align-middle">NombreMedico</th>
						<th class="align-middle">Diagnostico</th>
						<th class="align-middle">NombreMedicamento</th>
						<th class="align-middle">Cantidad</th>
						<th colspan="3" class="align-middle">Acciones</th>
					</tr>
				</thead>
				<tbody>';
		$sql = "SELECT r.IdReceta, r.IdConsulta, c.IdPaciente, p.Nombre as NombrePaciente, c.IdMedico, md.Nombre as NombreMedico, c.Diagnostico, r.IdMedicamento, m.Nombre AS NombreMedicamento, r.Cantidad 
		FROM recetas as r 
		JOIN consultas as c ON r.IdConsulta = c.IdConsulta 
		JOIN medicamentos as m ON r.IdMedicamento = m.IdMedicamento 
		JOIN medicos as md ON c.IdMedico = md.IdMedico 
		JOIN pacientes as p ON c.IdPaciente = p.IdPaciente 
		ORDER BY r.IdReceta ASC
		;";
		$res = $this->con->query($sql);
		// Sin codificar <td><a href="recetas.php?op=del&id=' . $row['id'] . '">Borrar</a></td>
		while ($row = $res->fetch_assoc()) {
			$d_del = "del/" . $row['IdReceta'];
			$d_del_final = base64_encode($d_del);
			$d_act = "act/" . $row['IdReceta'];
			$d_act_final = base64_encode($d_act);
			$d_det = "det/" . $row['IdReceta'];
			$d_det_final = base64_encode($d_det);
			$html .= '
			<tr>
				<td class="align-middle">' . $row['NombrePaciente'] . '</td>
				<td class="align-middle">' . $row['NombreMedico'] . '</td>
				<td class="align-middle">' . $row['Diagnostico'] . '</td>
				<td class="align-middle">' . $row['NombreMedicamento'] . '</td>
				<td class="align-middle">' . $row['Cantidad'] . '</td>
				
				<td class="align-middle"> <a class="btn btn-danger" href="recetas.php?d=' . $d_del_final . '"> <i class="fas fa-trash"></i> BORRAR</a></td>
				<td class="align-middle"> <a class="btn btn-primary" href="recetas.php?d=' . $d_act_final . '"> <i class="fas fa-pencil-alt"></i> ACTUALIZAR</a></td>
				<td class="align-middle"> <a class="btn btn-info" href="recetas.php?d=' . $d_det_final . '"> <i class="fas fa-info-circle"></i> DETALLE</a></td>

		</tr>';
		}
		$html .= '</tbody>
		</table>
		<a class="btn btn-success" href="../front/index.html" role="button">HOME</a>
	</div>';

		return $this->get_menu() . $html;
	}


	public function get_detail_receta($id)
	{
		$sql = "SELECT r.IdReceta, r.IdConsulta, c.IdPaciente, p.Nombre as NombrePaciente, c.IdMedico, md.Nombre as NombreMedico, c.Diagnostico, r.IdMedicamento, m.Nombre AS NombreMedicamento, r.Cantidad 
		FROM recetas as r 
		JOIN consultas as c ON r.IdConsulta = c.IdConsulta 
		JOIN medicamentos as m ON r.IdMedicamento = m.IdMedicamento 
		JOIN medicos as md ON c.IdMedico = md.IdMedico 
		JOIN pacientes as p ON c.IdPaciente = p.IdPaciente 
		WHERE r.IdReceta = $id;";
		$res = $this->con->query($sql);
		$row = $res->fetch_assoc();

		$num = $res->num_rows;

		//Si es que no existiese ningun registro debe desplegar un mensaje 
		//$mensaje = "tratar de eliminar la receta con id= ".$id;
		//echo $this->_message_error($mensaje);
		//y no debe desplegarse la tablas

		if ($num == 0) {
			$mensaje = "tratar de editar la receta con id= " . $id;
			echo $this->_message_error($mensaje);
		} else {
			$html = '
				<table border="1" align="center">
					<tr>
						<th colspan="6">DATOS PARA LA RECETA</th>
					</tr>
					<tr>
						<td>Paciente: </td>
						<td>' . $row['NombrePaciente'] . '</td>
					</tr>
					<tr>
						<td>Medico: </td>
						<td>' . $row['NombreMedico'] . '</td>
					</tr>
					<tr>
						<td>Diagnostico: </td>
						<td colspan="3">' . $row['Diagnostico'] . '</td>
					</tr>
					<tr>
						<td>Medicamento: </td>
						<td>' . $row['NombreMedicamento'] . '</td>
					</tr>
					<tr>
						<td>Cantidad: </td>
						<td>' . $row['Cantidad'] . '</td>
					</tr>
					<tr>
						<th colspan="2"><a href="recetas.php">Regresar</a></th>
					</tr>																						
				</table>';

			return $html;
		}
	}


	public function delete_receta($id)
	{
		$sql = "DELETE FROM recetas WHERE IdReceta=$id;";
		if ($this->con->query($sql)) {
			echo $this->_message_ok("ELIMINÓ");
		} else {
			echo $this->_message_error("eliminar");
		}
	}

	//*************************************************************************


	
	private function _message_error($tipo)
	{
		$html = '
		<div class="container text-center">
		<div class="alert alert-danger" role="alert">
		Error al ' . $tipo . '. Favor contactar a .................... <br>
			<a class="btn btn-danger" href="recetas.php">Regresar</a>
		</div>
	</div>';
		return $html;
	}


	private function _message_ok($tipo)
	{
		$html = '
		<div class="container text-center">
			<div class="alert alert-success" role="alert">
				El registro se ' . $tipo . ' correctamente <br>
				<a class="btn btn-success" href="recetas.php">Regresar</a>
			</div>
		</div>';
		return $html;
	}

	//****************************************************************************	

} // FIN SCRPIT
