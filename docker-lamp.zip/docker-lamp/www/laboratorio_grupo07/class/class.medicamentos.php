<?php
class medicamento
{
	private $IdMedicamento;
	private $Nombre;
	private $Tipo;
	
	private $con;

	function __construct($cn)
	{
		$this->con = $cn;
	}


	//*********************** 3.1 METODO update_medicamento() **************************************************	

	public function update_medicamento()
	{	
		$this->IdMedicamento = $_POST['IdMedicamento'];
		$this->Nombre = $_POST['Nombre'];
		$this->Tipo = $_POST['Tipo'];
	
		$sql = "UPDATE medicamentos SET
								Nombre='$this->Nombre',
								Tipo='$this->Tipo'
				WHERE IdMedicamento='$this->IdMedicamento';";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("modificó");
		} else {
			echo $this->_message_error("al modificar");
		}
	}


	//*********************** 3.2 METODO save_medicamento() **************************************************	

	public function save_medicamento()
	{
		$this->Nombre = $_POST['Nombre'];
		$this->Tipo = $_POST['Tipo'];


		$sql = "INSERT INTO medicamentos VALUES(NULL,
											'$this->Nombre',
											'$this->Tipo');";
		//echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("guardó");
		} else {
			echo $this->_message_error("guardar");
		}
	}



	//************************************* PARTE II ****************************************************	

	public function get_form($id = NULL)
	{

		if ($id == NULL) {
			$this->Nombre = NULL;
			$this->Tipo = NULL;

			$flag = NULL;
			$op = "new";
		} else {

			$sql = "SELECT * FROM medicamentos WHERE IdMedicamento=$id;";
			$res = $this->con->query($sql);
			$row = $res->fetch_assoc();

			$num = $res->num_rows;
			if ($num == 0) {
				$mensaje = "tratar de actualizar el medicamento con id= " . $id;
				echo $this->_message_error($mensaje);
			} else {

				// ***** TUPLA ENCONTRADA *****
				echo "<br>TUPLA <br>";
				echo "<pre>";
				print_r($row);
				echo "</pre>";

				$this->Nombre = $row['Nombre'];
				$this->Tipo = $row['Tipo'];

				$flag = "disabled";
				$op = "update";
			}
		}

		
		$html = '
		<form name="medicamento" method="POST" action="medicamento.php" enctype="multipart/form-data">
		
		<input type="hidden" name="IdMedicamento" value="' . $id  . '">
		<input type="hidden" name="op" value="' . $op  . '">
		
  		<table border="1" align="center">
				<tr>
					<th colspan="2">DATOS DEL MEDICAMENTO</th>
				</tr>
				<tr>
					<td>Nombre:</td>
					<td><input type="text" size="15" name="Nombre" value="' . $this->Nombre . '" required></td>
				</tr>
				
				<tr>
					<td>Tipo:</td>
					<td><input type="text" size="15" name="Tipo" value="' . $this->Tipo . '" required></td>
				</tr>	
				<tr>
					<th colspan="2"><input type="submit" name="Guardar" value="GUARDAR"></th>
                    <th colspan="3"><a class="btn btn-danger" href="medicamento.php" role="button">Cancelar</a></th>
				</tr>												
			</table>';
		return $html;
	}

	public function get_menu(){
        $menuHtml = '<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<img src="../front/Recursos/selloespe.jpg" alt="" height="50px" width="90px">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
			<li class="nav-item ">
				<a class="nav-link" href="usuarios.php">Usuarios</a>
			</li>
				<li class="nav-item ">
					<a class="nav-link" href="#">Consultas</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="pacientes.php">Pacientes</a>
				</li>
				<li class="nav-item ">
					<a class="nav-link" href="medicos.php">Medicos</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="medicamento.php">Medicamentos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Recetas</a>
				</li>
				<li class="nav-item">
                    <a class="nav-link" href="logout.php">Cerrar Sesión</a> 
				</li>
			</ul>
		</div>
	</nav>';

    return $menuHtml;
    }

	public function get_list()
	{
		$d_new = "new/0";
		$d_new_final = base64_encode($d_new);
		$html = '
		<div class="container">
			<table class="table table-bordered table-striped table-dark mx-auto text-center my-5">
				<thead class="thead-dark">
					<tr>
						<th colspan="8" class="align-middle">Lista de Medicamentos</th>
					</tr>
					<tr>
						<th colspan="8"><a class="btn btn-warning" href="medicamento.php?d=' . $d_new_final . '" role="button">Nuevo</a></th>
						
					</tr>
					<tr>
						<th class="align-middle">Nombre</th>
						<th class="align-middle">Tipo</th>
						<th colspan="3" class="align-middle">Acciones</th>
					</tr>
				</thead>
				<tbody>';
		$sql = "SELECT IdMedicamento, Nombre, Tipo  
		FROM medicamentos;";
		$res = $this->con->query($sql);
		// Sin codificar <td><a href="medicamento.php?op=del&id=' . $row['id'] . '">Borrar</a></td>
		while ($row = $res->fetch_assoc()) {
			$d_del = "del/" . $row['IdMedicamento'];
			$d_del_final = base64_encode($d_del);
			$d_act = "act/" . $row['IdMedicamento'];
			$d_act_final = base64_encode($d_act);
			$d_det = "det/" . $row['IdMedicamento'];
			$d_det_final = base64_encode($d_det);
			$html .= '
			<tr>
				<td class="align-middle">' . $row['Nombre'] . '</td>
				<td class="align-middle">' . $row['Tipo'] . '</td>
				
				<td class="align-middle"> <a class="btn btn-danger" href="medicamento.php?d=' . $d_del_final . '"> <i class="fas fa-trash"></i> BORRAR</a></td>
				<td class="align-middle"> <a class="btn btn-primary" href="medicamento.php?d=' . $d_act_final . '"> <i class="fas fa-pencil-alt"></i> ACTUALIZAR</a></td>
				<td class="align-middle"> <a class="btn btn-info" href="medicamento.php?d=' . $d_det_final . '"> <i class="fas fa-info-circle"></i> DETALLE</a></td>

		</tr>';
		}
		$html .= '</tbody>
		</table>
		<a class="btn btn-success" href="../index.html" role="button">HOME</a>
	</div>';

	return $this->get_menu() . $html;
	}


	public function get_detail_medicamento($id)
	{
		$sql = "SELECT IdMedicamento, Nombre, Tipo  
		FROM medicamentos
		WHERE IdMedicamento=$id;";
		$res = $this->con->query($sql);
		$row = $res->fetch_assoc();

		$num = $res->num_rows;

		//Si es que no existiese ningun registro debe desplegar un mensaje 
		//$mensaje = "tratar de eliminar el medicamento con id= ".$id;
		//echo $this->_message_error($mensaje);
		//y no debe desplegarse la tablas

		if ($num == 0) {
			$mensaje = "tratar de editar el medicamento con id= " . $id;
			echo $this->_message_error($mensaje);
		} else {
			$html = '
				<table border="1" align="center">
					<tr>
						<th colspan="2">DATOS DEL MEDICAMENTO</th>
					</tr>
					<tr>
						<td>Nombre: </td>
						<td>' . $row['Nombre'] . '</td>
					</tr>
					<tr>
					<td>Tipo: </td>
						<td>' . $row['Tipo'] . '</td>
					</tr>
					<tr>
						<th colspan="2"><a href="medicamento.php">Regresar</a></th>
					</tr>																						
				</table>';

			return $html;
		}
	}


	public function delete_medicamento($id)
	{
		$sql = "DELETE FROM medicamentos WHERE IdMedicamento=$id;";
		if ($this->con->query($sql)) {
			echo $this->_message_ok("ELIMINÓ");
		} else {
			echo $this->_message_error("eliminar");
		}
	}

	//*************************************************************************


	private function _message_error($tipo)
	{
		$html = '
		<div class="container text-center">
		<div class="alert alert-danger" role="alert">
		Error al ' . $tipo . '. Favor contactar a .................... <br>
			<a class="btn btn-danger" href="medicamento.php">Regresar</a>
		</div>
	</div>';
		return $html;
	}


	private function _message_ok($tipo)
	{
		$html = '
		<div class="container text-center">
			<div class="alert alert-success" role="alert">
				El registro se ' . $tipo . ' correctamente <br>
				<a class="btn btn-success" href="medicamento.php">Regresar</a>
			</div>
		</div>';
		return $html;
	}

	//****************************************************************************	

} // FIN SCRPIT
