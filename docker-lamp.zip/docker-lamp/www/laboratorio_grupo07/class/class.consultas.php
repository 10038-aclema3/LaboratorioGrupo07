<?php
class consultas
{
    private $IdConsulta;
    private $IdPaciente;
    private $IdMedico;
    private $FechaConsulta;
    private $HI;
    private $HF;
    private $Diagnostico;

    private $con;

    function __construct($cn)
    {
        $this->con = $cn;
    }


    //******** 3.1 METODO update_consulta() *****************	

    public function update_consulta()
    {
        $this->IdConsulta = $_POST['IdConsulta'];
        $this->IdPaciente = $_POST['IdPaciente'];
        $this->FechaConsulta = $_POST['FechaConsulta'];
        $this->HI = $_POST['HI'];
        $this->HF = $_POST['HF'];
        $this->Diagnostico = $_POST['Diagnostico'];


        $sql = "UPDATE consultas SET 
                    IdPaciente='$this->IdPaciente',
                    FechaConsulta='$this->FechaConsulta',
                    HI='$this->HI',
                    HF='$this->HF',
                    Diagnostico='$this->Diagnostico'
                WHERE IdConsulta='$this->IdConsulta';";

        if ($this->con->query($sql)) {
            echo $this->_message_ok("modificó");
        } else {
            echo $this->_message_error("al modificar");
        }
    }



    //******** 3.5 METODO verificar_turno() *****************	

    public function verificar_turno()
    {
        $this->IdMedico = $_POST['IdMedico'];
        $this->FechaConsulta = $_POST['FechaConsulta'];
        //$this->Genero = $_POST['Genero'];

        echo "<br> _POST <br>";
        echo "<pre>";
        print_r($_POST);
        echo "</pre>";

        $this->verificar_horarios_por_especialidad($this->IdMedico, $this->FechaConsulta, $this->FechaConsulta);
    }

    //******** 3.2 METODO save_consulta() *****************	

    public function save_consulta()
    {
        $this->IdConsulta = $_POST['IdConsulta'];
        $this->IdPaciente = $_POST['IdPaciente'];
        $this->IdMedico = $_POST['IdMedico'];
        $this->FechaConsulta = $_POST['FechaConsulta'];
        $this->HI = $_POST['HI'];
        $this->HF = $_POST['HF'];

        $this->Diagnostico = $_POST['Diagnostico'];


        $sql = "INSERT INTO consultas (IdPaciente, IdMedico, FechaConsulta, HI, HF, Diagnostico)
        VALUES ('$this->IdPaciente', '$this->IdMedico', '$this->FechaConsulta', '$this->HI', '$this->HF', '$this->Diagnostico')";



        echo $sql;
        //exit;
        if ($this->con->query($sql)) {
            echo $this->_message_ok("guardó");
        } else {
            echo $this->_message_error("guardar");
        }
    }


    //******** 3.3 METODO _get_name_File() *****************	

    private function _get_name_file($nombre_original, $tamanio)
    {
        $tmp = explode(".", $nombre_original); //Divido el nombre por el punto y guardo en un arreglo
        $numElm = count($tmp); //cuento el número de elemetos del arreglo
        $ext = $tmp[$numElm - 1]; //Extraer la última posición del arreglo.
        $cadena = "";
        for ($i = 1; $i <= $tamanio; $i++) {
            $c = rand(65, 122);
            if (($c >= 91) && ($c <= 96)) {
                $c = NULL;
                $i--;
            } else {
                $cadena .= chr($c);
            }
        }
        return $cadena . "." . $ext;
    }

    
    //******** 3.4 obtener especialidades por género *****************	

    public function get_horarios_por_especialidad($especialidad)
    {
        $horario_especialidad = array(
            "1"  => "Lunes a viernes", //Cardiologia
            "2"  => "Lunes a viernes", //Pediatría
            "3"  => "Lunes a viernes", //Dermatología
            "5"  => "Lunes a viernes", //Oftalmología
            "4"  => "Lunes, miercoles y viernes </br> Martes y jueves no hay atención" //Ginecología
        );
        if (array_key_exists($especialidad, $horario_especialidad)) {
            $horario = $horario_especialidad[$especialidad];
        } else {
            $horario = "El horario para esta especialidad no existe";
        }
        $horario .= "</br>Sabado y domingo no hay atención";
        return $horario;
    }

    //******** 3.5 validar fecha por especialidad *****************	

    public function validar_atencion($fecha, $especialidad)
    {
        $diaSemana = date('w', strtotime($fecha));
        if ($diaSemana == 0 || $diaSemana == 6) {
            $horario = "Sabado y domingo no hay atención";
        } else {
            if (($diaSemana == 2 || $diaSemana == 4) && $especialidad == 4 ) {
                $horario = "Martes y jueves no hay atención";
            } else {
                $horario = "OK";
            }
        }

        return $horario;
    }


    //************* PARTE I ********************


    private function _get_combo_db($tabla, $valor, $etiqueta, $nombre, $defecto)
    {
        $html = '<select name="' . $nombre . '">';
        $sql = "SELECT $valor,$etiqueta FROM $tabla;";
        $res = $this->con->query($sql);
        while ($row = $res->fetch_assoc()) {
            //ImpResultQuery($row);
            $html .= ($defecto == $row[$valor]) ? '<option value="' . $row[$valor] . '" selected>' . $row[$etiqueta] . '</option>' . "\n" : '<option value="' . $row[$valor] . '">' . $row[$etiqueta] . '</option>' . "\n";
        }
        $html .= '</select>';
        return $html;
    }

    private function _get_combo_db_medicos($nombreSelect, $defecto)
    {
        $html = '<select name="' . $nombreSelect . '" id="' . $nombreSelect . '">';
    
        $sql = "SELECT m.IdMedico, CONCAT(m.Nombre, ' - ', e.Descripcion) AS NombreMedico
                FROM medicos m
                JOIN especialidades e ON m.Especialidad = e.IdEsp;";
    
        $res = $this->con->query($sql);
    
        while ($row = $res->fetch_assoc()) {
            $html .= ($defecto == $row['IdMedico']) ? '<option value="' . $row['IdMedico'] . '" selected>' . $row['NombreMedico'] . '</option>' . "\n" : '<option value="' . $row['IdMedico'] . '">' . $row['NombreMedico'] . '</option>' . "\n";
        }
    
        $html .= '</select>';
        return $html;
    }
    


    private function _get_radio($arreglo, $nombre, $defecto)
    {

        $html = '
		<table border=0 align="left">';

        //CODIGO NECESARIO EN CASO QUE EL USUARIO NO SE ESCOJA UNA OPCION

        foreach ($arreglo as $etiqueta) {
            $html .= '
			<tr>
				<td>' . $etiqueta . '</td>
				<td>';

            if ($defecto == NULL) {
                // OPCION PARA GRABAR UN NUEVA CONSULTA (id=0)
                $html .= '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>';
            } else {
                // OPCION PARA MODIFICAR UNA CONUSLTA EXISTENTE
                $html .= ($defecto == $etiqueta) ? '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>' : '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '"/></td>';
            }

            $html .= '</tr>';
        }
        $html .= '
		</table>';
        return $html;
    }


    //************* PARTE II ******************	

    public function get_form($id = NULL)
    {
        if ($id == NULL) {
            $this->IdConsulta = NULL;
            $this->IdPaciente = NULL;
            $this->IdMedico = NULL;
            $this->FechaConsulta = NULL;
            $this->HI = NULL;
            $this->HF = NULL;
            $this->Diagnostico = NULL;

            $flag = "enable";
            $op = "new";
        } else {

            $sql = "SELECT c.IdConsulta, CONCAT(m.Nombre, ' - ', e.Descripcion) AS NombreMedico, c.IdMedico, p.IdPaciente, p.Nombre, c.FechaConsulta, c.HI, c.HF, c.Diagnostico
                     FROM consultas c
                     JOIN medicos m ON c.IdMedico = m.IdMedico
                     JOIN pacientes p ON c.IdPaciente = p.IdPaciente
                     JOIN especialidades e ON m.Especialidad = e.IdEsp
                     WHERE c.IdConsulta = $id;";

            $res = $this->con->query($sql);
            $row = $res->fetch_assoc();

            $num = $res->num_rows;
            if ($num == 0) {
                $mensaje = "tratar de actualizar el consultas con id= " . $id;
                echo $this->_message_error($mensaje);
            } else {

                // ** TUPLA ENCONTRADA **
                
                echo "<br>TUPLA <br>";
                echo "<pre>";
                print_r($row);
                echo "</pre>";
                
                $this->IdConsulta = $row['IdConsulta'];
                $this->IdPaciente = $row['IdPaciente'];
                $this->IdMedico = $row['IdMedico'];
                $this->FechaConsulta = $row['FechaConsulta'];
                $this->HI = $row['HI'];
                $this->HF = $row['HF'];
                $this->Diagnostico = $row['Diagnostico'];

                $flag = "disabled";
                $op = "update";
            }
        }
        $html = '
		    <form name="consultas" method="POST" action="consultas.php" enctype="multipart/form-data">
		
		    <input type="hidden" name="IdConsulta" value="' . $id . '">
            <input type="hidden" name="op" value="' . $op  . '">

		
  		    <table border="1" align="center">
				<tr>
					<th colspan="8">DATOS PARA LA CONSULTA</th>
				</tr>
                <tr>
					<td>Paciente:</td>
                    <td colspan="3">' . $this->_get_combo_db("pacientes", "IdPaciente", "Nombre", "IdPaciente", $this->IdPaciente) . '</td>
				</tr>
                <tr>
					<td>Medico:</td> 
                    <td colspan="3">' . $this->_get_combo_db_medicos("IdMedico", $this->IdMedico) . '</td>
                
                        <span id="horarioEspecialidades"></span>
                    </td>
				</tr>
                <tr>
					<td>Fecha:</td>
					<td colspan="6"><input type="date" size="15" name="FechaConsulta" id="FechaConsulta" value="' . $this->FechaConsulta . '" required onchange="getValidarAtencion(event)" >
                    </br>
                    <span id="validacionFecha"></span>
                    </td>
				</tr>
                <tr>
					<td>Hora de Inicio:</td>
					<td colspan="6"><input type="text" size="15" name="HI" value="' . $this->HI . '" required></td>
				</tr>
                <tr>
					<td>Hora Final:</td>
					<td colspan="6"><input type="text" size="15" name="HF" value="' . $this->HF . '" required></td>
				</tr>
                <tr>
					<td>Diagnostico:</td>
					<td colspan="6"><input type="text" size="15" name="Diagnostico" value="' . $this->Diagnostico . '" required></td>
				</tr>
				
				<tr>
                    <th colspan="3"><input type="submit" name="Guardar" value="GUARDAR"></th>
                    <th colspan="3"><a class="btn btn-danger" href="consultas.php" role="button">Cancelar</a></th>
				</tr>												
			</table>';

        return $html;
    }


    public function get_menu(){
        $menuHtml = '<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<img src="../front/Recursos/selloespe.jpg" alt="" height="50px" width="90px">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
                 <li class="nav-item ">
                    <a class="nav-link" href="consultas.php">Consultas</a>
                 </li>
				<li class="nav-item">
					<a class="nav-link" href="#">Pacientes</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Medicos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Medicamentos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="recetas.php">Recetas</a>
				</li>
				<li class="nav-item">
                    <a class="nav-link" href="logout.php">Cerrar Sesión</a> 
				</li>
			</ul>
		</div>
	</nav>';

    return $menuHtml;
    }

    public function get_list()
    {
        $d_new = "new/0";
        $d_new_final = base64_encode($d_new);
        $html = '
        <div class="container">
            <table class="table table-bordered table-striped table-dark mx-auto text-center my-5">
				<thead class="thead-dark">
                    <tr>
                        <th colspan="10" class="align-middle">Lista de Consultas</th>
                    </tr>
                    <tr>
                        <th colspan="10"><a class="btn btn-warning" href="consultas.php?d=' . $d_new_final . '" role="button">Nuevo</a></th>
                    </tr>
                    <tr>
                        <th class="align-middle">IdConsulta</th>
                        <th class="align-middle">Medico</th>
                        <th class="align-middle">Paciente</th>
                        <th class="align-middle">FechaConsulta</th>
                        <th class="align-middle">Hora de inicio</th>
                        <th class="align-middle">Hora final</th>
                        <th class="align-middle">Diagnositco</th>
                        <th colspan="3">Acciones</th>
                    </tr>';
        $sql = "SELECT c.IdConsulta, m.Nombre AS NombreMedico,p.Nombre AS NombrePaciente, c.FechaConsulta,c.HI,c.HF, c.Diagnostico
                FROM consultas c
                JOIN  medicos m ON c.IdMedico = m.IdMedico
                JOIN pacientes p ON c.IdPaciente = p.IdPaciente
                ORDER BY c.IdConsulta ASC;";
        $res = $this->con->query($sql);
        // Sin codificar <td><a href="consultas.php?op=del&id=' . $row['IdConsulta'] . '">Borrar</a></td>
        while ($row = $res->fetch_assoc()) {
            $d_del = "del/" . $row['IdConsulta'];
            $d_del_final = base64_encode($d_del);
            $d_act = "act/" . $row['IdConsulta'];
            $d_act_final = base64_encode($d_act);
            $d_det = "det/" . $row['IdConsulta'];
            $d_det_final = base64_encode($d_det);
            $html .= '
				<tr>
                    <td class="align-middle">' . $row['IdConsulta'] . '</td>
                    <td class="align-middle">' . $row['NombrePaciente'] . '</td>
					<td class="align-middle">' . $row['NombreMedico'] . '</td>
					<td class="align-middle">' . $row['FechaConsulta'] . '</td>
					<td class="align-middle">' . $row['HI'] . '</td>
					<td class="align-middle">' . $row['HF'] . '</td>
					<td class="align-middle">' . $row['Diagnostico'] . '</td>
					<td class="align-middle"><a class="btn btn-primary" href="consultas.php?d=' . $d_act_final . '"> <i class="fas fa-pencil-alt"></i> ACTUALIZAR</a></td>
					<td class="align-middle"><a class="btn btn-info" href="consultas.php?d=' . $d_det_final . '">    <i class="fas fa-info-circle"></i> DETALLE</a></td>
				</tr>';
        }
        $html .= '</tbody>
		</table>
		<a class="btn btn-success" href="../front/index.html" role="button">HOME</a>
	</div>';

        return $this->get_menu() . $html;
    }


    public function get_detail_consulta($id)
    {
        $sql = "SELECT c.IdConsulta, CONCAT(m.Nombre, ' - ', e.Descripcion) AS NombreMedico, p.Nombre AS NombrePaciente, c.FechaConsulta, c.HI, c.HF, c.Diagnostico
        FROM consultas c
        JOIN medicos m ON c.IdMedico = m.IdMedico
        JOIN pacientes p ON c.IdPaciente = p.IdPaciente
        JOIN especialidades e ON m.Especialidad = e.IdEsp

        WHERE c.IdConsulta = $id;";
        $res = $this->con->query($sql);
        $row = $res->fetch_assoc();

        $num = $res->num_rows;

        //Si es que no existiese ningun registro debe desplegar un mensaje 
        //$mensaje = "tratar de eliminar la consulta con IdConsulta= ".IdConsulta;
        //echo $this->_message_error($mensaje);
        //y no debe desplegarse la tablas

        if ($num == 0) {
            $mensaje = "tratar de editar la consulta con id= " . $id;
            echo $this->_message_error($mensaje);
        } else {
            $html = '
				<table border="1" align="center">
					<tr>
						<th colspan="4">DATOS DE LA CONSULTA</th>
					</tr>
					<tr>
						<td>Paciente: </td>
						<td>' . $row['NombrePaciente'] . '</td>
					</tr>
					<tr>
						<td>Medico: </td>
						<td>' . $row['NombreMedico'] . '</td>
					</tr>
					<tr>
						<td>Fecha: </td>
						<td colspan="3">' . $row['FechaConsulta'] . '</td>
					</tr>
					<tr>
						<td>Hora de Inicio: </td>
						<td colspan="3">' . $row['HI'] . '</td>
					</tr>
					<tr>
						<td>Hora Final: </td>
						<td colspan="3">' . $row['HF'] . '</td>
					</tr>
					<tr>
						<td>Diagnostico: </td>
						<td colspan="3">' . $row['Diagnostico'] . '</td>
					</tr>
					<tr>
						<th colspan="4"><a href="consultas.php">Regresar</a></th>
					</tr>																						
				</table>';

            return $html;
        }
    }


    public function delete($id): string
	{
		$sql = "DELETE FROM consultas WHERE IdConsulta=$id;";
		if ($this->con->query($sql)) {
			return $this->_message_ok("ELIMINÓ");
		} else {
            return $this->_message_error("eliminar");
		}
	}



    //*************************
    // HORARIOS
    //*************************	
    private function verificar_horarios_por_especialidad($medicoID, $fechaConsulta, $horaConsulta)
    {
        $horarios = [];
        // Obtener el día de la semana para la fecha de consulta
        $diaSemana = strtoupper(date('l', strtotime($fechaConsulta)));

        // Convertir la hora de consulta a formato entero
        $horaConsulta = intval($horaConsulta);

        // Filtrar los horarios para el médico y día específicos
        $horariosMedico = array_filter($horarios, function ($horario) use ($medicoID, $diaSemana) {
            return $horario['EspecialidadID'] == $medicoID && $horario['Dia'] == $diaSemana;
        });

        // Verificar disponibilidad en el horario indicado
        foreach ($horariosMedico as $horario) {
            $horaInicio = intval($horario['horaInicio']);
            $horaFin = intval($horario['horaFin']);

            if ($horaConsulta >= $horaInicio && $horaConsulta < $horaFin) {
                return true; // Hay disponibilidad
            }
        }

        return false; // No hay disponibilidad
    }

    function saber_dia($nombredia): string
    {
        $dias = array('Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado');
        $dia = $dias[date('N', strtotime($nombredia))];

        return $dia;
    }

    //*************************

    //*************************	
    private function _message_error($tipo)
    {
        $html = '
		<div class="container text-center">
		<div class="alert alert-danger" role="alert">
		Error al ' . $tipo . '. Favor contactar a .................... <br>
			<a class="btn btn-danger" href="consultas.php">Regresar</a>
		</div>
	</div>
				 ';
        return $html;
    }


    private function _message_ok($tipo)
    {
        $html = '
		<div class="container text-center">
			<div class="alert alert-success" role="alert">
				El registro se ' . $tipo . ' correctamente <br>
				<a class="btn btn-success" href="consultas.php">Regresar</a>
			</div>
		</div>';
        return $html;
    }

    //**************************	

} // FIN SCRPIT
