<?php
class usuario
{
    private $IdUsuario;
    private $Nombre;
    private $Rol;
    private $Password;
    private $Foto;
    private $IdRol;

    private $con;

    private $page;
    private $table;

    function __construct($cn, $page)
    {
        $this->con = $cn;
        $this->page = $page;
        $this->table = substr(strtolower($page), 0, -1);
    }


    //*********************** 3.1 METODO update() **************************************************

    public function update()
    {
        $this->IdUsuario = $_POST['IdUsuario'];
        $this->Rol = $_POST['Rol'];
        $this->Nombre = $_POST['Nombre'];
        $this->Password = $_POST['Password'];

        $sql = "UPDATE usuarios SET 
                    Rol='$this->Rol',
                    Nombre='$this->Nombre',
                    Password='$this->Password'
				WHERE IdUsuario='$this->IdUsuario';";
        echo $sql;
        //exit;
        if ($this->con->query($sql)) {
            echo $this->_message_ok("modificó");
        } else {
            echo $this->_message_error("al modificar");
        }
    }


    //*********************** 3.2 METODO save() **************************************************

    public function save()
    {
        $this->IdUsuario = $_POST['IdUsuario'];
        $this->Rol = $_POST['Rol'];
        $this->Nombre = $_POST['Nombre'];
        $this->Password = $_POST['Password'];
        $this->Foto = $_FILES['Foto']['name'];
        /*
        echo "<br> FILES <br>";
        echo "<pre>";
        print_r($_FILES);
        echo "</pre>";
        */

        $this->Foto = $this->_get_name_file($_FILES['Foto']['name'], 12);

        $path = PATH . $this->Foto;

        //exit;
        if (!move_uploaded_file($_FILES['Foto']['tmp_name'], $path)) {
            $mensaje = "Cargar la imagen";
            echo $this->_message_error($mensaje);
            exit;
        }

        $sql = "INSERT INTO usuarios (IdUsuario, Rol, Nombre, Password, Foto) VALUES (NULL,
											'$this->Rol',
											'$this->Nombre',
											'$this->Password',
											'$this->Foto'
											);";
        echo $sql;
        //exit;
        if ($this->con->query($sql)) {
            echo $this->_message_ok("guardó");
        } else {
            echo $this->_message_error("guardar");
        }
    }

      //******** 3.3 METODO _get_name_File() *****************	

      private function _get_name_file($nombre_original, $tamanio)
      {
          $tmp = explode(".", $nombre_original); //Divido el nombre por el punto y guardo en un arreglo
          $numElm = count($tmp); //cuento el número de elemetos del arreglo
          $ext = $tmp[$numElm - 1]; //Extraer la última posición del arreglo.
          $cadena = "";
          for ($i = 1; $i <= $tamanio; $i++) {
              $c = rand(65, 122);
              if (($c >= 91) && ($c <= 96)) {
                  $c = NULL;
                  $i--;
              } else {
                  $cadena .= chr($c);
              }
          }
          return $cadena . "." . $ext;
      }

    //*************************************** PARTE I ************************************************************

    private function _get_radio($arreglo, $nombre, $defecto)
    {

        $html = '
		<table border=0 align="left">';

        //CODIGO NECESARIO EN CASO QUE EL USUARIO NO SE ESCOJA UNA OPCION

        foreach ($arreglo as $etiqueta) {
            $html .= '
			<tr>
				<td>' . $etiqueta . '</td>
				<td>';

            if ($defecto == NULL) {
                // OPCION PARA GRABAR UN NUEVO PERSONA (id=0)
                $html .= '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>';
            } else {
                // OPCION PARA MODIFICAR UN PERSONA EXISTENTE
                $html .= ($defecto == $etiqueta) ? '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>' : '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '"/></td>';
            }

            $html .= '</tr>';
        }
        $html .= '
		</table>';
        return $html;
    }

    private function _get_combo_db($tabla, $valor, $etiqueta, $nombreSelect, $defecto)
    {
        $html = '<select name="' . $nombreSelect . '" id="' . $nombreSelect . '">';
        $sql = "SELECT $valor,$etiqueta FROM $tabla;";
        $res = $this->con->query($sql);
        while ($row = $res->fetch_assoc()) {
            //ImpResultQuery($row);
            $html .= ($defecto == $row[$valor]) ? '<option value="' . $row[$valor] . '" selected>' . $row[$etiqueta] . '</option>' . "\n" : '<option value="' . $row[$valor] . '">' . $row[$etiqueta] . '</option>' . "\n";
        }
        $html .= '</select>';
        return $html;
    }

    //************************************* PARTE II ****************************************************	

    public function get_form($id = NULL)
    {

        if ($id == NULL) {
            $this->IdUsuario = NULL;
            $this->Nombre = NULL;
            $this->Rol = NULL;
            $this->Foto = NULL;
            $this->Password = NULL;
            $this->IdRol = NULL;

            $flag = NULL;
            $op = "new";
        } else {

            $sql = "SELECT u.IdUsuario, u.Nombre, u.Password, u.Rol AS idRol, r.Nombre AS Rol, u.Foto 
                    FROM usuarios AS u
                    INNER JOIN roles AS r ON u.Rol = r.IdRol
                    WHERE IdUsuario=$id;";
            $res = $this->con->query($sql);
            $row = $res->fetch_assoc();

            $num = $res->num_rows;
            if ($num == 0) {
                $mensaje = "tratar de actualizar el persona con id= " . $id;
                echo $this->_message_error($mensaje);
            } else {
                /*
				// ***** TUPLA ENCONTRADA *****
				echo "<br>TUPLA <br>";
				echo "<pre>";
				print_r($row);
				echo "</pre>";
				*/
                $this->IdUsuario = $row['IdUsuario'];
                $this->Nombre = $row['Nombre'];
                $this->Rol = $row['Rol'];
                $this->Password = $row['Password'];
                $this->Foto = $row['Foto'];

                $flag = "disabled";
                $op = "update";
            }
        }

        $html = '
		<form name="personas" method="POST" action="usuarios.php" enctype="multipart/form-data">
		
		<input type="hidden" name="IdUsuario" value="' . $id  . '">
		<input type="hidden" name="Rol" value="' . $id  . '">
		<input type="hidden" name="op" value="' . $op  . '">
		
  		<table border="1" align="center">
				<tr>
					<th colspan="2">DATOS DEL USUARIO</th>
				</tr>
				<tr>
					<td>Nombre:</td>
					<td><input type="text" size="20" name="Nombre" value="' . $this->Nombre . '" required></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="password" size="20" name="Password" value="' . $this->Password . '" required></td>
				</tr>	
				<tr>
					<td>Rol:</td>
                    <td colspan="3">' . $this->_get_combo_db("roles", "IdRol", "Nombre", "Rol", $this->IdRol) . '</td>
				</tr>
				<tr>
					<td>Foto Nueva:</td>
                    <td colspan="6"><input type="file" name="Foto" ' . $this->Foto . '></td>
				</tr>
				<tr>
					<th colspan="2"><input type="submit" name="Guardar" value="GUARDAR"></th>
                    <th colspan="3"><a class="btn btn-danger" href="usuarios.php" role="button">Cancelar</a></th>
				</tr>												
			</table>';
        return $html;
    }

    public function get_menu()
    {
        $menuHtml = '<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<img src="../front/Recursos/selloespe.jpg" alt="" height="50px" width="90px">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
        <li class="nav-item active">
            <a class="nav-link" href="usuarios.php">Usuarios</a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="#">Consultas</a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="pacientes.php">Pacientes</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="medicos.php">Medicos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="medicamento.php">Medicamentos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Recetas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="logout.php">Cerrar Sesión</a> 
        </li>
    </ul>
		</div>
	</nav>';

        return $menuHtml;
    }

    public function get_list()
    {
        $d_new = "new/0";
        $d_new_final = base64_encode($d_new);
        $html = '
		<div class="container">
			<table class="table table-bordered table-striped table-dark mx-auto text-center my-5">
				<thead class="thead-dark">
					<tr>
						<th colspan="8" class="align-middle">Lista de ' . $this->page . '</th>
					</tr>
					<tr>
						<th colspan="8"><a class="btn btn-warning" href="usuarios.php?d=' . $d_new_final . '" role="button">Nuevo</a></th>
						
					</tr>
					<tr>
						<th class="align-middle">IdUsuario</th>
						<th class="align-middle">Rol</th>
						<th class="align-middle">Usuario</th>
						<th colspan="3" class="align-middle">Acciones</th>
					</tr>
				</thead>
				<tbody>';
        $sql = 'SELECT u.IdUsuario, u.Nombre, u.Password, u.Rol AS idRol, r.Nombre AS Rol, u.Foto
                        FROM usuarios AS u
                        INNER JOIN roles AS r ON u.Rol = r.IdRol
                        ORDER BY u.IdUsuario ASC;';

        $res = $this->con->query($sql);
        // Sin codificar <td><a href="personas.php?op=del&id=' . $row['id'] . '">Borrar</a></td>
        while ($row = $res->fetch_assoc()) {
            $d_del = "del/" . $row['IdUsuario'];
            $d_del_final = base64_encode($d_del);
            $d_act = "act/" . $row['IdUsuario'];
            $d_act_final = base64_encode($d_act);
            $d_det = "det/" . $row['IdUsuario'];
            $d_det_final = base64_encode($d_det);
            $html .= '
			<tr>
				<td class="align-middle">' . $row['IdUsuario'] . '</td>
				<td class="align-middle">' . $row['Rol'] . '</td>
				<td class="align-middle">' . $row['Nombre'] . '</td>
				
				<td class="align-middle"> <a class="btn btn-danger" href="usuarios.php?d=' . $d_del_final . '"> <i class="fas fa-trash"></i> BORRAR</a></td>
				<td class="align-middle"> <a class="btn btn-primary" href="usuarios.php?d=' . $d_act_final . '"> <i class="fas fa-pencil-alt"></i> ACTUALIZAR</a></td>
				<td class="align-middle"> <a class="btn btn-info" href="usuarios.php?d=' . $d_det_final . '"> <i class="fas fa-info-circle"></i> DETALLE</a></td>

		</tr>';
        }
        $html .= '</tbody>
		</table>
		<a class="btn btn-success" href="../front/index.html" role="button">HOME</a>
	</div>';

        return $this->get_menu() . $html;
    }


    public function get_detail($id)
    {
        $sql = "SELECT u.IdUsuario, u.Nombre, u.Password, u.Rol AS idRol, r.Nombre AS Rol, u.Foto
                FROM usuarios AS u
                INNER JOIN roles AS r ON u.Rol = r.IdRol
                WHERE IdUsuario=$id ;";

        $res = $this->con->query($sql);
        $row = $res->fetch_assoc();

        $num = $res->num_rows;

        //Si es que no existiese ningun registro debe desplegar un mensaje 
        //$mensaje = "tratar de eliminar el persona con id= ".$id;
        //echo $this->_message_error($mensaje);
        //y no debe desplegarse la tablas

        if ($num == 0) {
            $mensaje = "tratar de editar el item con id= " . $id;
            echo $this->_message_error($mensaje);
        } else {
            $html = '
				<table border="1" align="center">
					<tr>
						<th colspan="2">DATOS DEL USUARIO</th>
					</tr>
					<tr>
						<td>Rol: </td>
						<td>' . $row['Rol'] . '</td>
					</tr>
					<tr>
						<td>Nombre: </td>
						<td>' . $row['Nombre'] . '</td>
					</tr>
					<tr>
						<td>Clave: </td>
						<td>' . $row['Password'] . '</td>
					</tr>	
					<tr>
						<th colspan="4"><img src=" ' . PATH . $row['Foto'] . '" width="300px"/></th>
					</tr>	
					
					<tr>
						<th colspan="2"><a href="usuarios.php">Regresar</a></th>
					</tr>																						
				</table>';

            return $html;
        }
    }


    public function delete($id): string
    {
        $sql = "DELETE FROM usuarios WHERE IdUsuario=$id;";
        if ($this->con->query($sql)) {
            return $this->_message_ok("ELIMINÓ");
        } else {
            return $this->_message_error("eliminar");
        }
    }


    //*************************************************************************	

    private function _message_error($tipo)
    {
        $html = '
		<div class="container text-center">
		<div class="alert alert-danger" role="alert">
		Error al ' . $tipo . '. Favor contactar a .................... <br>
			<a class="btn btn-danger" href="usuarios.php">Regresar</a>
		</div>
	</div>
				 ';
        return $html;
    }


    private function _message_ok($tipo)
    {
        $html = '
		<div class="container text-center">
			<div class="alert alert-success" role="alert">
				El registro se ' . $tipo . ' correctamente <br>
				<a class="btn btn-success" href="usuarios.php">Regresar</a>
			</div>
		</div>';
        return $html;
    }

    //****************************************************************************	

} // FIN SCRPIT
