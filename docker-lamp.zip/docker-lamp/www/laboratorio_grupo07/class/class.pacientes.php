<?php
class pacientes
{
	private $IdPaciente;
	private $IdUsuario;
	private $Nombre;
	private $Cedula;
	private $Edad;
	private $Genero;
	private $Estatura;
	private $Peso;
	private $con;

	function __construct($cn)
	{
		$this->con = $cn;
	}


	//*********************** 3.1 METODO update_paciente() **************************************************	

	public function update_paciente()
	{
		$this->IdPaciente = $_POST['IdPaciente'];
		$this->IdUsuario = $_POST['IdUsuario'];
		$this->Nombre = $_POST['Nombre'];
		$this->Cedula = $_POST['Cedula'];
		$this->Edad = $_POST['Edad'];
		$this->Genero = $_POST['Genero'];
		$this->Estatura = $_POST['Estatura'];
		$this->Peso = $_POST['Peso'];



		$sql = "UPDATE pacientes SET IdUsuario='$this->IdUsuario',
									Nombre='$this->Nombre',
									Cedula='$this->Cedula',
									Edad='$this->Edad',
									Genero='$this->Genero',
									Estatura='$this->Estatura',
									Peso='$this->Peso'
				WHERE IdPaciente='$this->IdPaciente';";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("modificó");
		} else {
			echo $this->_message_error("al modificar");
		}
	}


	//*********************** 3.2 METODO save_paciente() **************************************************	

	public function save_paciente()
	{

		$this->IdPaciente = $_POST['IdPaciente'];
		$this->IdUsuario = $_POST['IdUsuario'];
		$this->Nombre = $_POST['Nombre'];
		$this->Cedula = $_POST['Cedula'];
		$this->Edad = $_POST['Edad'];
		$this->Genero = $_POST['Genero'];
		$this->Estatura = $_POST['Estatura'];
		$this->Peso = $_POST['Peso'];


		$sql = "INSERT INTO pacientes (IdPaciente, IdUsuario, Nombre, Cedula, Edad, Genero, Estatura, Peso) VALUES(NULL,
											'$this->IdUsuario',
											'$this->Nombre',
											'$this->Cedula',
											'$this->Edad',
											'$this->Genero',
											'$this->Estatura',
											'$this->Peso');";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("guardó");
		} else {
			echo $this->_message_error("guardar");
		}
	}



	//*************************************** PARTE I ************************************************************


	/*Aquí se agregó el parámetro:  $defecto*/
	private function _get_radio($arreglo, $nombre, $defecto)
	{

		$html = '
		<table border=0 align="left">';

		//CODIGO NECESARIO EN CASO QUE EL USUARIO NO SE ESCOJA UNA OPCION

		foreach ($arreglo as $etiqueta) {
			$html .= '
			<tr>
				<td>' . $etiqueta . '</td>
				<td>';

			if ($defecto == NULL) {
				// OPCION PARA GRABAR UN NUEVO PACIENTE (id=0)
				$html .= '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>';
			} else {
				// OPCION PARA MODIFICAR UN PACIENTE EXISTENTE
				$html .= ($defecto == $etiqueta) ? '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>' : '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '"/></td>';
			}

			$html .= '</tr>';
		}
		$html .= '
		</table>';
		return $html;
	}

	private function _get_combo_db($tabla, $valor, $etiqueta, $nombreSelect, $defecto)
	{
		$html = '<select name="' . $nombreSelect . '" id="' . $nombreSelect . '">';
		$sql = "SELECT $valor, $etiqueta FROM $tabla;";
		$res = $this->con->query($sql);
		while ($row = $res->fetch_assoc()) {
			//ImpResultQuery($row);
			$html .= ($defecto == $row[$valor]) ? '<option value="' . $row[$valor] . '" selected>' . $row[$etiqueta] . '</option>' . "\n" : '<option value="' . $row[$valor] . '">' . $row[$etiqueta] . '</option>' . "\n";
		}
		$html .= '</select>';
		return $html;
	}

	private function _get_combo_db_pacientes($nombreSelect, $defecto)
	{
		$html = '<select name="' . $nombreSelect . '" id="' . $nombreSelect . '">';

		$sql = "SELECT u.IdUsuario, u.Nombre 
            FROM usuarios u
            JOIN roles r ON u.Rol = r.IdRol
            WHERE r.Nombre = 'Paciente';";

		$res = $this->con->query($sql);

		while ($row = $res->fetch_assoc()) {
			$html .= ($defecto == $row['IdUsuario']) ? '<option value="' . $row['IdUsuario'] . '" selected>' . $row['Nombre'] . '</option>' . "\n" : '<option value="' . $row['IdUsuario'] . '">' . $row['Nombre'] . '</option>' . "\n";
		}

		$html .= '</select>';
		return $html;
	}



	//************************************* PARTE II ****************************************************	

	public function get_form($id = NULL)
	{

		if ($id == NULL) {
			$this->IdUsuario = NULL;
			$this->Nombre = NULL;
			$this->Edad = NULL;
			$this->Cedula = NULL;
			$this->Genero = NULL;
			$this->Estatura = NULL;
			$this->Peso = NULL;

			$flag = NULL;
			$op = "new";
		} else {

			$sql = "SELECT p.IdPaciente, p.IdUsuario, p.Nombre As NombrePaciente, p.Cedula, p.Edad, p.Genero, p.Estatura, p.Peso, u.Nombre AS Usuario, u.Foto   
			FROM pacientes AS p 
			INNER JOIN usuarios AS u ON p.IdUsuario = u.IdUsuario 
			WHERE IdPaciente=$id;";
			$res = $this->con->query($sql);
			$row = $res->fetch_assoc();

			$num = $res->num_rows;
			if ($num == 0) {
				$mensaje = "tratar de actualizar el paciente con id= " . $id;
				echo $this->_message_error($mensaje);
			} else {

				// ***** TUPLA ENCONTRADA *****
				echo "<br>TUPLA <br>";
				echo "<pre>";
				print_r($row);
				echo "</pre>";

				$this->IdUsuario = $row['IdUsuario'];
				$this->Nombre = $row['NombrePaciente'];
				$this->Cedula = $row['Cedula'];
				$this->Edad = $row['Edad'];
				$this->Genero = $row['Genero'];
				$this->Estatura = $row['Estatura'];
				$this->Peso = $row['Peso'];

				$flag = "disabled";
				$op = "update";
			}
		}


		$genero = [
			"Masculino",
			"Femenino"
		];
		$html = '
		<form name="pacientes" method="POST" action="pacientes.php" enctype="multipart/form-data">
		
		<input type="hidden" name="IdPaciente" value="' . $id  . '">
		<input type="hidden" name="IdUsuario" value="' . $id  . '">
		<input type="hidden" name="op" value="' . $op  . '">
		
  		<table border="1" align="center">
				<tr>
					<th colspan="2">DATOS DEL PACIENTE</th>
				</tr>
				<tr>
					<td>Nombre:</td>
					<td><input type="text" size="20" name="Nombre" value="' . $this->Nombre . '" required></td>
				</tr>
				<tr>
					<td>Usuario:</td>
					<td colspan="3">' . $this->_get_combo_db_pacientes("IdUsuario", $this->IdUsuario) . '</td>
				</tr>
				<tr>
					<td>Cedula:</td>
					<td><input type="text" size="20" name="Cedula" value="' . $this->Cedula . '" required></td>
				</tr>
				<tr>
					<td>Edad:</td>
					<td><input type="number" size="20" name="Edad" value="' . $this->Edad . '" required></td>
				</tr>
				<tr>
					<td>Genero:</td>
					<td>' . $this->_get_radio($genero, "Genero", $this->Genero) . '</td>
				</tr>
				<tr>
					<td>Estatura:</td>
					<td><input type="text" size="20" name="Estatura" value="' . $this->Estatura . '" required></td>
				</tr>
				<tr>
					<td>Peso:</td>
					<td><input type="text" size="20" name="Peso" value="' . $this->Peso . '" required></td>
				</tr>
				<tr>
					<th colspan="2"><input type="submit" name="Guardar" value="GUARDAR"></th>
                    <th colspan="3"><a class="btn btn-danger" href="pacientes.php" role="button">Cancelar</a></th>
				</tr>												
			</table>';
		return $html;
	}


	public function get_menu(){
        $menuHtml = '<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<img src="../front/Recursos/selloespe.jpg" alt="" height="50px" width="90px">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item ">
					<a class="nav-link" href="usuarios.php">Usuarios</a>
				</li>
				<li class="nav-item ">
					<a class="nav-link" href="#">Consultas</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="pacientes.php">Pacientes</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="medicos.php">Medicos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="medicamento.php">Medicamentos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Recetas</a>
				</li>
				<li class="nav-item">
                    <a class="nav-link" href="logout.php">Cerrar Sesión</a> 
				</li>
			</ul>
		</div>
	</nav>';

    return $menuHtml;
    }

	public function get_list()
	{
		$d_new = "new/0";
		$d_new_final = base64_encode($d_new);
		$html = '
		<div class="container">
			<table class="table table-bordered table-striped table-dark mx-auto text-center my-5">
				<thead class="thead-dark">
					<tr>
						<th colspan="11" class="align-middle">Lista de Pacientes</th>
					</tr>
					<tr>
						<th colspan="11"><a class="btn btn-warning" href="pacientes.php?d=' . $d_new_final . '" role="button">Nuevo</a></th>
						
					</tr>
					<tr>
						<th class="align-middle">IdPaciente</th>
						<th class="align-middle">Nombre</th>
						<th class="align-middle">Cedula</th>
						<th class="align-middle">Edad</th>
						<th class="align-middle">Genero</th>
						<th class="align-middle">Estatura</th>
						<th class="align-middle">Peso</th>
						<th class="align-middle">Usuario</th>
						<th colspan="3" class="align-middle">Acciones</th>
					</tr>
				</thead>
				<tbody>';
		$sql = "SELECT p.IdPaciente, p.IdUsuario, p.Nombre As NombrePaciente, p.Cedula, p.Edad, p.Genero, p.Estatura, p.Peso, u.Nombre AS Usuario, u.Foto   
		FROM pacientes AS p 
		INNER JOIN usuarios AS u ON p.IdUsuario = u.IdUsuario;";
		$res = $this->con->query($sql);
		// Sin codificar <td><a href="pacientes.php?op=del&id=' . $row['id'] . '">Borrar</a></td>
		while ($row = $res->fetch_assoc()) {
			$d_del = "del/" . $row['IdPaciente'];
			$d_del_final = base64_encode($d_del);
			$d_act = "act/" . $row['IdPaciente'];
			$d_act_final = base64_encode($d_act);
			$d_det = "det/" . $row['IdPaciente'];
			$d_det_final = base64_encode($d_det);
			$html .= '
			<tr>
				<td class="align-middle">' . $row['IdPaciente'] . '</td>
				<td class="align-middle">' . $row['NombrePaciente'] . '</td>
				<td class="align-middle">' . $row['Cedula'] . '</td>
				<td class="align-middle">' . $row['Edad'] . '</td>
				<td class="align-middle">' . $row['Genero'] . '</td>
				<td class="align-middle">' . $row['Estatura'] . '</td>
				<td class="align-middle">' . $row['Peso'] . '</td>
				<td class="align-middle">' . $row['Usuario'] . '</td>
				
				<td class="align-middle"> <a class="btn btn-danger" href="pacientes.php?d=' . $d_del_final . '"> <i class="fas fa-trash"></i> BORRAR</a></td>
				<td class="align-middle"> <a class="btn btn-primary" href="pacientes.php?d=' . $d_act_final . '"> <i class="fas fa-pencil-alt"></i> ACTUALIZAR</a></td>
				<td class="align-middle"> <a class="btn btn-info" href="pacientes.php?d=' . $d_det_final . '"> <i class="fas fa-info-circle"></i> DETALLE</a></td>

		</tr>';
		}
		$html .= '</tbody>
		</table>
		<a class="btn btn-success" href="../index.html" role="button">HOME</a>
	</div>';

		return $this->get_menu() . $html;
	}


	public function get_detail_paciente($id)
	{
		$sql = "SELECT p.IdPaciente, p.IdUsuario, p.Nombre As NombrePaciente, p.Cedula, p.Edad, p.Genero, p.Estatura, p.Peso, u.Nombre AS Usuario, u.Foto   
				FROM pacientes AS p 
				INNER JOIN usuarios AS u ON p.IdUsuario = u.IdUsuario
				WHERE IdPaciente=$id ;";
		$res = $this->con->query($sql);
		$row = $res->fetch_assoc();

		$num = $res->num_rows;

		//Si es que no existiese ningun registro debe desplegar un mensaje 
		//$mensaje = "tratar de eliminar el paciente con id= ".$id;
		//echo $this->_message_error($mensaje);
		//y no debe desplegarse la tablas

		if ($num == 0) {
			$mensaje = "tratar de editar el paciente con id= " . $id;
			echo $this->_message_error($mensaje);
		} else {
			$html = '
				<table border="1" align="center">
					<tr>
						<th colspan="2">DATOS DEL PACIENTE</th>
					</tr>
					<tr>
						<td>Nombre: </td>
						<td>' . $row['NombrePaciente'] . '</td>
					</tr>
					<tr>
						<td>Cedula: </td>
						<td>' . $row['Cedula'] . '</td>
					</tr>
					<tr>
						<td>Edad: </td>
						<td>' . $row['Edad'] . '</td>
					</tr>
					<tr>
						<td>Genero: </td>
						<td>' . $row['Genero'] . '</td>
					</tr>
					<tr>
						<td>Estatura: </td>
						<td>' . $row['Estatura'] . '</td>
					</tr>
					<tr>
						<td>Peso: </td>
						<td>' . $row['Peso'] . '</td>
					</tr>
					<tr>
						<td>Usuario: </td>
						<td>' . $row['Usuario'] . '</td>
					</tr>	
					<tr>
						<th colspan="4"><img src=" ' . PATH . $row['Foto'] . '" width="300px"/></th>
					</tr>
					
					<tr>
						<th colspan="2"><a href="pacientes.php">Regresar</a></th>
					</tr>																						
				</table>';

			return $html;
		}
	}


	public function delete_paciente($id)
	{
		$sql = "DELETE FROM pacientes WHERE IdPaciente=$id;";
		if ($this->con->query($sql)) {
			echo $this->_message_ok("ELIMINÓ");
		} else {
			echo $this->_message_error("eliminar");
		}
	}


	//*************************************************************************	

	private function _message_error($tipo)
	{
		$html = '
		<div class="container text-center">
		<div class="alert alert-danger" role="alert">
		Error al ' . $tipo . '. Favor contactar a .................... <br>
			<a class="btn btn-danger" href="pacientes.php">Regresar</a>
		</div>
	</div>';
		return $html;
	}


	private function _message_ok($tipo)
	{
		$html = '
		<div class="container text-center">
			<div class="alert alert-success" role="alert">
				El registro se ' . $tipo . ' correctamente <br>
				<a class="btn btn-success" href="pacientes.php">Regresar</a>
			</div>
		</div>';
		return $html;
	}

	//****************************************************************************	

} // FIN SCRPIT
