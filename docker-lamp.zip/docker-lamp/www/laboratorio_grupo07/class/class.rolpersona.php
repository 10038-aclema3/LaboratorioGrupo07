<?php
class RolPersona
{
	private $RolPersonaId;
	private $RolNombre;
 
	private $con;

	function __construct($cn)
	{
		$this->con = $cn;
	}


	//*********************** 3.1 METODO update_rolpersona() **************************************************	

	public function update_rolpersona()
	{
		$this->RolPersonaId = $_POST['RolPersonaId'];
		$this->RolNombre = $_POST['RolNombre']; 


		$sql = "UPDATE rolpersona SET RolNombre='$this->RolNombre',		 
				WHERE RolNombre='$this->RolNombre';";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("modificó");
		} else {
			echo $this->_message_error("al modificar");
		}
	}


	//*********************** 3.2 METODO save_rolpersona() **************************************************	

	public function save_rolpersona()
	{

		$this->RolNombre = $_POST['RolNombre']; 
		
		
		$sql = "INSERT INTO rolpersona (`RolNombre`) VALUES(
											'$this->RolNombre');
											 ";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("guardó");
		} else {
			echo $this->_message_error("guardar");
		}
	}




	//*************************************** PARTE I ************************************************************


	/*Aquí se agregó el parámetro:  $defecto*/
	private function _get_combo_db($tabla, $valor, $etiqueta, $nombre, $defecto)
	{
		$html = '<select name="' . $nombre . '">';
		$sql = "SELECT $valor,$etiqueta FROM $tabla;";
		$res = $this->con->query($sql);
		while ($row = $res->fetch_assoc()) {
			//ImpResultQuery($row);
			$html .= ($defecto == $row[$valor]) ? '<option value="' . $row[$valor] . '" selected>' . $row[$etiqueta] . '</option>' . "\n" : '<option value="' . $row[$valor] . '">' . $row[$etiqueta] . '</option>' . "\n";
		}
		$html .= '</select>';
		return $html;
	}

	

	/*Aquí se agregó el parámetro:  $defecto*/
	private function _get_radio($arreglo, $nombre, $defecto)
	{

		$html = '
		<table border=0 align="left">';

		//CODIGO NECESARIO EN CASO QUE EL USUARIO NO SE ESCOJA UNA OPCION

		foreach ($arreglo as $etiqueta) {
			$html .= '
			<tr>
				<td>' . $etiqueta . '</td>
				<td>';

			if ($defecto == NULL) {
				// OPCION PARA GRABAR UN NUEVA ROL (id=0)
				$html .= '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>';
			} else {
				// OPCION PARA MODIFICAR UN ROL EXISTENTE
				$html .= ($defecto == $etiqueta) ? '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>' : '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '"/></td>';
			}

			$html .= '</tr>';
		}
		$html .= '
		</table>';
		return $html;
	}


	//************************************* PARTE II ****************************************************	

	public function get_form($id = NULL)
	{

		if ($id == NULL) {
			$this->RolNombre = NULL; 

			$flag = NULL;
			$op = "new";
		} else {
            $sql = "SELECT *
            FROM rolpersona WHERE RolPersonaId=$id
    ;";
			 
			$res = $this->con->query($sql);
			$row = $res->fetch_assoc();

			$num = $res->num_rows;
			if ($num == 0) {
				$mensaje = "tratar de actualizar la rol con id= " . $id;
				echo $this->_message_error($mensaje);
			} else {

				// ***** TUPLA ENCONTRADA *****
				// echo "<br>TUPLA <br>";
				// echo "<pre>";
				// print_r($row);
				// echo "</pre>";

				$this->RolNombre = $row['RolNombre']; 
				$flag = "disabled";
				$op = "update";
			}
		}


		$html = '
		<form name="rol" method="POST" action="rolpersona.php" enctype="multipart/form-data">
		
		<input type="hidden" name="RolPersonaId" value="' . $id  . '">
		 
		<input type="hidden" name="op" value="' . $op  . '">
		
  		<table border="1" align="center">
				 <tr>
					<th colspan="2">ROLES</th>
				</tr>
				<tr>
					<td>Rol:</td>
					<td>		<input type=" text" name="RolNombre" value="' . $this->RolNombre  . '"></td>
				</tr>
				<tr>
					<th colspan="2"><input type="submit" name="Guardar" value="GUARDAR"></th>
                    <th colspan="3"><a class="btn btn-danger" href="rolpersona.php" role="button">Cancelar</a></th>
				</tr>												
			</table>';
		return $html;
	}

	public function get_menu(){
        $menuHtml = '<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<img src="../front/Recursos/selloespe.jpg" alt="" height="50px" width="90px">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="./estudiante.php">Estudiante</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="./profesor.php">Profesor</a>
				</li>
				<li class="nav-item ">
					<a class="nav-link" href="./personas.php">Persona</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="./rolpersona.php">Rol</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="./departamento.php">Departamento</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="./nrcmateria.php">NRC Materia</a>
				</li>
				<li class="nav-item">
                    <a href="logout.php">Cerrar Sesión</a> 
				</li>
			</ul>
		</div>
	</nav>';

    return $menuHtml;
    }

	public function get_list_rolpersona()
	{
		$d_new = "new/0";
		$d_new_final = base64_encode($d_new);
		$html = '
		<div class="container">
			<table class="table table-bordered table-striped table-dark mx-auto text-center my-5">
				<thead class="thead-dark">
					<tr>
						<th colspan="8" class="align-middle">Lista de Roles</th>
					</tr>
					<tr>
						<th colspan="8"><a class="btn btn-warning" href="rolpersona.php?d=' . $d_new_final . '" role="button">Nuevo</a></th>
						
					</tr>
					<tr>
						<th class="align-middle">Roles</th>
						 
						<th colspan="3" class="align-middle">Acciones</th>
					</tr>
				</thead>
				<tbody>';
		$sql = "SELECT *
				FROM rolpersona 
		;";
		$res = $this->con->query($sql);
		// Sin codificar <td><a href="rolpersona.php?op=del&id=' . $row['id'] . '">Borrar</a></td>
		while ($row = $res->fetch_assoc()) {
			$d_del = "del/" . $row['RolPersonaId'];
			$d_del_final = base64_encode($d_del);
			$d_act = "act/" . $row['RolPersonaId'];
			$d_act_final = base64_encode($d_act);
			$d_det = "det/" . $row['RolPersonaId'];
			$d_det_final = base64_encode($d_det);
			$html .= '
			<tr>
				<td class="align-middle">' . $row['RolNombre'] . '</td>
				 
				
				<td class="align-middle"> <a class="btn btn-danger" href="rolpersona.php?d=' . $d_del_final . '"> <i class="fas fa-trash"></i> BORRAR</a></td>
				 

		</tr>';
		}
		$html .= '</tbody>
        <tfoot>
            <tr>
                <th colspan="8">Solo se pueden agregar y eliminar los roles</th>
            </tr>
		</table>
		<a class="btn btn-success" href="../front/index.html" role="button">HOME</a>
	</div>';

		return $this->get_menu() . $html;
	}


	public function get_detail_rolpersona($id)
	{
		$sql = "SELECT r.RolPersonaId, r.RolNombre, c.PacienteID, p.Nombre as NombrePaciente, p.Edad, p.Genero, c.MedicoID, md.Nombre as NombreMedico, c.Diagnostico, r.MedicamentoID, m.Nombre AS NombreMedicamento, r.Cantidad 
		FROM recetas as r 
		JOIN consultas as c ON r.RolNombre=c.RolNombre 
		JOIN medicamentos as m ON r.MedicamentoID=m.MedicamentoID 
		JOIN medicos as md ON c.MedicoID=md.MedicoID 
		JOIN pacientes as p ON c.PacienteID=p.PacienteID 
		WHERE r.RolPersonaId = $id;";
		$res = $this->con->query($sql);
		$row = $res->fetch_assoc();

		$num = $res->num_rows;

		//Si es que no existiese ningun registro debe desplegar un mensaje 
		//$mensaje = "tratar de eliminar la receta con id= ".$id;
		//echo $this->_message_error($mensaje);
		//y no debe desplegarse la tablas

		if ($num == 0) {
			$mensaje = "tratar de editar la receta con id= " . $id;
			echo $this->_message_error($mensaje);
		} else {
			$html = '
				<table border="1" align="center">
					<tr>
						<th colspan="6">DATOS PARA LA RECETA</th>
					</tr>
					<tr>
						<td>Paciente: </td>
						<td>' . $row['NombrePaciente'] . '</td>
					</tr>
					<tr>
						<td>Edad: </td>
						<td>' . $row['Edad'] . '</td>
					</tr>
					<tr>
						<td>Genero: </td>
						<td>' . $row['Genero'] . '</td>
					</tr>
					<tr>
						<td>Medico: </td>
						<td>' . $row['NombreMedico'] . '</td>
					</tr>
					<tr>
						<td>Diagnostico: </td>
						<td colspan="3">' . $row['Diagnostico'] . '</td>
					</tr>
					<tr>
						<td>Medicamento: </td>
						<td>' . $row['NombreMedicamento'] . '</td>
					</tr>
					<tr>
						<td>Cantidad: </td>
						<td>' . $row['Cantidad'] . '</td>
					</tr>
					<tr>
						<th colspan="2"><a href="rolpersona.php">Regresar</a></th>
					</tr>																						
				</table>';

			return $html;
		}
	}


	public function delete_rolpersona($id)
	{
		$sql = "DELETE FROM rolpersona WHERE RolPersonaId=$id;";
		if ($this->con->query($sql)) {
			echo $this->_message_ok("ELIMINÓ");
		} else {
			echo $this->_message_error("eliminar");
		}
	}

	//*************************************************************************

	private function _calculo_matricula($avaluo)
	{
		return number_format(($avaluo * 0.10), 2);
	}

	//*************************************************************************	

	private function _message_error($tipo)
	{
		$html = '
		<div class="container text-center">
		<div class="alert alert-danger" role="alert">
		Error al ' . $tipo . '. Favor contactar a .................... <br>
			<a class="btn btn-danger" href="rolpersona.php">Regresar</a>
		</div>
	</div>';
		return $html;
	}


	private function _message_ok($tipo)
	{
		$html = '
		<div class="container text-center">
			<div class="alert alert-success" role="alert">
				El registro se ' . $tipo . ' correctamente <br>
				<a class="btn btn-success" href="rolpersona.php">Regresar</a>
			</div>
		</div>';
		return $html;
	}

	//****************************************************************************	

} // FIN SCRPIT
