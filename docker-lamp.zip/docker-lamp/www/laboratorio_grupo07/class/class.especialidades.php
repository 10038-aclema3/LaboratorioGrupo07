<?php
class especialidad
{
	private $IdEsp;
	private $Descripcion;
    private $Dias;
    private $Franja_HI;
    private $Franja_HF;

    private $con;

    private $page;
    private $table;

	function __construct($cn, $page)
	{
        $this->con = $cn;
	}


	//*********************** 3.1 METODO update() **************************************************

	public function update()
	{
        $this->IdEsp = $_POST['IdEsp'];
        $this->Descripcion = $_POST['Descripcion'];
        $this->Dias = $_POST['Dias'];
        $this->Franja_HI = $_POST['Franja_HI'];
        $this->Franja_HF = $_POST['Franja_HF'];

		$sql = "UPDATE especialidades SET 
                    Descripcion='$this->Descripcion',
                    Dias='$this->Dias',
                    Franja_HI='$this->Franja_HI',
                    Franja_HF='$this->Franja_HF'
				WHERE IdEsp='$this->IdEsp';";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("modificó");
		} else {
			echo $this->_message_error("al modificar");
		}
	}


	//*********************** 3.2 METODO save() **************************************************

	public function save()
	{
        $this->IdEsp = $_POST['IdEsp'];
        $this->Descripcion = $_POST['Descripcion'];
        $this->Dias = $_POST['Dias'];
        $this->Franja_HI = $_POST['Franja_HI'];
        $this->Franja_HF = $_POST['Franja_HF'];

		$sql = "INSERT INTO especialidades (IdEsp, Descripcion, Dias, Franja_HI, Franja_HF) VALUES (NULL,
											'$this->Descripcion',
											'$this->Dias',
											'$this->Franja_HI',
											'$this->Franja_HF'
											);";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("guardó");
		} else {
			echo $this->_message_error("guardar");
		}
	}

	//*************************************** PARTE I ************************************************************

    private function _get_combo_db($tabla, $valor, $etiqueta, $nombreSelect, $defecto)
    {
        $html = '<select name="' . $nombreSelect . '" id="' . $nombreSelect . '">';
        $sql = "SELECT $valor, $etiqueta FROM $tabla;";
        $res = $this->con->query($sql);
        while ($row = $res->fetch_assoc()) {
            //ImpResultQuery($row);
            $html .= ($defecto == $row[$valor]) ? '<option value="' . $row[$valor] . '" selected>' . $row[$etiqueta] . '</option>' . "\n" : '<option value="' . $row[$valor] . '">' . $row[$etiqueta] . '</option>' . "\n";
        }
        $html .= '</select>';
        return $html;
    }

    private function _get_combo_db_doble_campo($tabla, $valor, $etiqueta, $campoA, $campoB, $nombreSelect, $defecto)
    {
        $html = '<select name="' . $nombreSelect . '" id="' . $nombreSelect . '">';
        $sql = "SELECT $valor, CONCAT($campoA, ' ', $campoB) AS $etiqueta FROM $tabla;";
        $res = $this->con->query($sql);
        while ($row = $res->fetch_assoc()) {
            //ImpResultQuery($row);
            $html .= ($defecto == $row[$valor]) ? '<option value="' . $row[$valor] . '" selected>' . $row[$etiqueta] . '</option>' . "\n" : '<option value="' . $row[$valor] . '">' . $row[$etiqueta] . '</option>' . "\n";
        }
        $html .= '</select>';
        return $html;
    }

	//************************************* PARTE II ****************************************************	

	public function get_form($id = NULL)
	{

		if ($id == NULL) {
			$this->IdEsp = NULL;
            $this->Descripcion = NULL;
            $this->Dias = NULL;
            $this->Franja_HI = NULL;
            $this->Franja_HF = NULL;

			$flag = NULL;
			$op = "new";
		} else {

			$sql = "SELECT *
                    FROM especialidades
                    WHERE IdEsp=$id;";
			$res = $this->con->query($sql);
			$row = $res->fetch_assoc();

			$num = $res->num_rows;
			if ($num == 0) {
				$mensaje = "tratar de actualizar el item con id= " . $id;
				echo $this->_message_error($mensaje);
			} else {
				/*
				// ***** TUPLA ENCONTRADA *****
				echo "<br>TUPLA <br>";
				echo "<pre>";
				print_r($row);
				echo "</pre>";
				*/
                $this->IdEsp = $row['IdEsp'];
                $this->Descripcion = $row['Descripcion'];
                $this->Dias = $row['Dias'];
                $this->Franja_HI = $row['Franja_HI'];
                $this->Franja_HF = $row['Franja_HF'];

				$flag = "disabled";
				$op = "update";
			}
		}

		$html = '
		<form name="especialidades" method="POST" action="especialidades.php" enctype="multipart/form-data">
		
		<input type="hidden" name="IdEsp" value="' . $id  . '">
		<input type="hidden" name="op" value="' . $op  . '">
		
  		<table border="1" align="center">
				<tr>
					<th colspan="2">DATOS DEL PROFESOR</th>
				</tr>
				<tr>
					<td>Descripcion:</td>
                    <td><input type="text" size="20" name="Descripcion" value="' . $this->Descripcion . '" required></td>
				</tr>
				<tr>
					<td>Días:</td>
                    <td><input type="text" size="20" name="Dias" value="' . $this->Dias . '" required></td>
				</tr>
				<tr>
					<td>Hora de Inicio:</td>
                    <td><input type="text" size="20" name="Franja_HI" value="' . $this->Franja_HI . '" required></td>
				</tr>
				<tr>
					<td>Hora Final:</td>
                    <td><input type="text" size="20" name="Franja_HF" value="' . $this->Franja_HF . '" required></td>
				</tr>
				<tr>
					<th colspan="2"><input type="submit" name="Guardar" value="GUARDAR"></th>
                    <th colspan="3"><a class="btn btn-danger" href="especialidades.php" role="button">Cancelar</a></th>
				</tr>												
			</table>';
		return $html;
	}


	public function get_menu(){
        $menuHtml = '<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<img src="../front/Recursos/selloespe.jpg" alt="" height="50px" width="90px">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item ">
					<a class="nav-link" href="#">Estudiante</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="./profesor.php">Profesor</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Persona</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Rol</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Departamento</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">NRC Materia</a>
				</li>
				<li class="nav-item">
                    <a href="logout.php">Cerrar Sesión</a> 
				</li>
			</ul>
		</div>
	</nav>';

    return $menuHtml;
    }	
	public function get_list()
	{
		$d_new = "new/0";
		$d_new_final = base64_encode($d_new);
		$html = '
		<div class="container">
			<table class="table table-bordered table-striped table-dark mx-auto text-center my-5">
				<thead class="thead-dark">
					<tr>
						<th colspan="8" class="align-middle">Lista de Especialidades </th>
					</tr>
					<tr>
						<th colspan="8"><a class="btn btn-warning" href="especialidades.php?d=' . $d_new_final . '" role="button">Nuevo</a></th>
						
					</tr>
					<tr>
						<th class="align-middle">IdEsp</th>
						<th class="align-middle">Descripcion</th>
						<th class="align-middle">Dias</th>
						<th class="align-middle">Franja_HI</th>
						<th class="align-middle">Franja_HF</th>
						<th colspan="3" class="align-middle">Acciones</th>
					</tr>
				</thead>
				<tbody>';
		$sql = "SELECT *
                    FROM especialidades;";

		$res = $this->con->query($sql);
		// Sin codificar <td><a href="especialidades.php?op=del&id=' . $row['id'] . '">Borrar</a></td>
		while ($row = $res->fetch_assoc()) {
			$d_del = "del/" . $row['IdEsp'];
			$d_del_final = base64_encode($d_del);
			$d_act = "act/" . $row['IdEsp'];
			$d_act_final = base64_encode($d_act);
			$d_det = "det/" . $row['IdEsp'];
			$d_det_final = base64_encode($d_det);
			$html .= '
			<tr>
				<td class="align-middle">' . $row['IdEsp'] . '</td>
				<td class="align-middle">' . $row['Descripcion'] . '</td>
				<td class="align-middle">' . $row['Dias'] . '</td>
				<td class="align-middle">' . $row['Franja_HI'] . '</td>
				<td class="align-middle">' . $row['Franja_HF'] . '</td>
				
				<td class="align-middle"> <a class="btn btn-danger" href="especialidades.php?d=' . $d_del_final . '"> <i class="fas fa-trash"></i> BORRAR</a></td>
				<td class="align-middle"> <a class="btn btn-primary" href="especialidades.php?d=' . $d_act_final . '"> <i class="fas fa-pencil-alt"></i> ACTUALIZAR</a></td>
				<td class="align-middle"> <a class="btn btn-info" href="especialidades.php?d=' . $d_det_final . '"> <i class="fas fa-info-circle"></i> DETALLE</a></td>

		</tr>';
		}
		$html .= '</tbody>
		</table>
	</div>';

		return $this->get_menu() . $html;
	}


	public function get_detail($id)
	{
        $sql = "SELECT *
                    FROM especialidades
                    WHERE IdEsp=$id;";
		$res = $this->con->query($sql);
		$row = $res->fetch_assoc();

		$num = $res->num_rows;

		//Si es que no existiese ningun registro debe desplegar un mensaje 
		//$mensaje = "tratar de eliminar el profesor con id= ".$id;
		//echo $this->_message_error($mensaje);
		//y no debe desplegarse la tablas

		if ($num == 0) {
			$mensaje = "tratar de editar el item con id= " . $id;
			echo $this->_message_error($mensaje);
		} else {
			$html = '
				<table border="1" align="center">
					<tr>
						<th colspan="2">DATOS DEL PROFESOR</th>
					</tr>
					<tr>
						<td>Nombre: </td>
						<td>' . $row['Descripcion'] . '</td>
					</tr>
					<tr>
						<td>Departamento: </td>
						<td>' . $row['Dias'] . '</td>
					</tr>
					<tr>
						<td>Sueldo: </td>
						<td>' . $row['Franja_HI'] . '</td>
					</tr>
					<tr>
						<td>Sueldo: </td>
						<td>' . $row['Franja_HF'] . '</td>
					</tr>
					
					<tr>
						<th colspan="2"><a href="../especialidades.php">Regresar</a></th>
					</tr>																						
				</table>';

			return $html;
		}
	}


	public function delete($id): string
	{
		$sql = "DELETE FROM especialidades WHERE IdEsp=$id;";
		if ($this->con->query($sql)) {
			return $this->_message_ok("ELIMINÓ");
		} else {
            return $this->_message_error("eliminar");
		}
	}


	//*************************************************************************	

	private function _message_error($tipo)
	{
		$html = '
		<div class="container text-center">
		<div class="alert alert-danger" role="alert">
		Error al ' . $tipo . '. Favor contactar a .................... <br>
			<a class="btn btn-danger" href="especialidades.php">Regresar</a>
		</div>
	</div>';
		return $html;
	}


	private function _message_ok($tipo)
	{
		$html = '
		<div class="container text-center">
			<div class="alert alert-success" role="alert">
				El registro se ' . $tipo . ' correctamente <br>
				<a class="btn btn-success" href="especialidades.php">Regresar</a>
			</div>
		</div>';
		return $html;
	}

	//****************************************************************************	

} // FIN SCRPIT
