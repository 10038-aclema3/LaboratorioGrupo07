<?php
class medicos
{
	private $IdMedico;
	private $Nombre;
	private $Especialidad;
	private $IdUsuario;
	
	private $con;

	function __construct($cn)
	{
		$this->con = $cn;
	}


	//*********************** 3.1 METODO update_medicos() **************************************************	

	public function update_medicos()
	{	
		$this->IdMedico = $_POST['IdMedico'];
		$this->Nombre = $_POST['Nombre'];
		$this->Especialidad = $_POST['Especialidad'];
		$this->IdUsuario = $_POST['IdUsuario'];
	
		$sql = "UPDATE medicos SET
								Nombre='$this->Nombre',
								Especialidad='$this->Especialidad',
								IdUsuario='$this->IdUsuario'
				WHERE IdMedico='$this->IdMedico';";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("modificó");
		} else {
			echo $this->_message_error("al modificar");
		}
	}


	//*********************** 3.2 METODO save_medicos() **************************************************	

	public function save_medico()
	{
		$this->IdMedico = $_POST['IdMedico'];
		$this->Nombre = $_POST['Nombre'];
		$this->Especialidad = $_POST['Especialidad'];
		$this->IdUsuario = $_POST['IdUsuario'];


		$sql = "INSERT INTO medicos (IdMedico, Nombre, Especialidad, IdUsuario)VALUES(NULL,
											'$this->Nombre',
											'$this->Especialidad',
											'$this->IdUsuario'
											);";
		echo $sql;
		//exit;
		if ($this->con->query($sql)) {
			echo $this->_message_ok("guardó");
		} else {
			echo $this->_message_error("guardar");
		}
	}


	//*************************************** PARTE I ************************************************************


	/*Aquí se agregó el parámetro:  $defecto*/
	private function _get_combo_db($tabla, $valor, $etiqueta, $nombre, $defecto)
	{
		$html = '<select name="' . $nombre . '">';
		$sql = "SELECT $valor,$etiqueta FROM $tabla;";
		$res = $this->con->query($sql);
		while ($row = $res->fetch_assoc()) {
			//ImpResultQuery($row);
			$html .= ($defecto == $row[$valor]) ? '<option value="' . $row[$valor] . '" selected>' . $row[$etiqueta] . '</option>' . "\n" : '<option value="' . $row[$valor] . '">' . $row[$etiqueta] . '</option>' . "\n";
		}
		$html .= '</select>';
		return $html;
	}

	/*Aquí se agregó el parámetro:  $defecto*/
	private function _get_radio($arreglo, $nombre, $defecto)
	{

		$html = '
		<table border=0 align="left">';

		//CODIGO NECESARIO EN CASO QUE EL USUARIO NO SE ESCOJA UNA OPCION

		foreach ($arreglo as $etiqueta) {
			$html .= '
			<tr>
				<td>' . $etiqueta . '</td>
				<td>';

			if ($defecto == NULL) {
				// OPCION PARA GRABAR UN NUEVO MEDICO (id=0)
				$html .= '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>';
			} else {
				// OPCION PARA MODIFICAR UN MEDICO EXISTENTE
				$html .= ($defecto == $etiqueta) ? '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '" checked/></td>' : '<input type="radio" value="' . $etiqueta . '" name="' . $nombre . '"/></td>';
			}

			$html .= '</tr>';
		}
		$html .= '
		</table>';
		return $html;
	}


	//************************************* PARTE II ****************************************************	

	public function get_form($id = NULL)
	{

		if ($id == NULL) {
			$this->Nombre = NULL;
			$this->Especialidad = NULL;
			$this->IdUsuario = NULL;

			$flag = NULL;
			$op = "new";
		} else {

			$sql = "SELECT m.IdMedico, m.Nombre, m.Especialidad, e.Descripcion, m.IdUsuario, u.Nombre AS Usuario
			FROM medicos AS m
			INNER JOIN especialidades AS e ON m.Especialidad = e.IdEsp
			INNER JOIN usuarios AS u ON m.IdUsuario = u.IdUsuario
					WHERE IdMedico=$id;";
			$res = $this->con->query($sql);
			$row = $res->fetch_assoc();

			$num = $res->num_rows;
			if ($num == 0) {
				$mensaje = "tratar de actualizar el medico con id= " . $id;
				echo $this->_message_error($mensaje);
			} else {

				// ***** TUPLA ENCONTRADA *****
				echo "<br>TUPLA <br>";
				echo "<pre>";
				print_r($row);
				echo "</pre>";

				$this->Nombre = $row['Nombre'];
				$this->Especialidad = $row['Especialidad'];
				$this->IdUsuario = $row['IdUsuario'];
				$this->IdUsuario = $row['IdUsuario'];

				$flag = "disabled";
				$op = "update";
			}
		}

		
		$html = '
		<form name="medico" method="POST" action="medicos.php" enctype="multipart/form-data">
		
		<input type="hidden" name="IdMedico" value="' . $id  . '">
		<input type="hidden" name="op" value="' . $op  . '">
		
  		<table border="1" align="center">
				<tr>
					<th colspan="2">DATOS DEL MEDICO</th>
				</tr>
				<tr>
					<td>Nombre:</td>
					<td><input type="text" size="15" name="Nombre" value="' . $this->Nombre . '" required></td>
				</tr>
				<tr>
					<td>Especialidad:</td>
					<td colspan="3">' . $this->_get_combo_db("especialidades", "IdEsp", "Descripcion", "Especialidad", $this->Especialidad) . '</td>
				</tr>	
				<tr>
					<td>Usuario:</td>
					<td colspan="3">' . $this->_get_combo_db("usuarios", "IdUsuario", "Nombre", "IdUsuario", $this->IdUsuario) . '</td>
				</tr>	
				<tr>
					<th colspan="2"><input type="submit" name="Guardar" value="GUARDAR"></th>
                    <th colspan="3"><a class="btn btn-danger" href="medicos.php" role="button">Cancelar</a></th>
				</tr>												
			</table>';
		return $html;
	}


	public function get_menu(){
        $menuHtml = '<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
		<img src="../front/Recursos/selloespe.jpg" alt="" height="50px" width="90px">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
			<li class="nav-item ">
				<a class="nav-link" href="usuarios.php">Usuarios</a>
			</li>
				<li class="nav-item ">
					<a class="nav-link" href="#">Consultas</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="pacientes.php">Pacientes</a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="medicos.php">Medicos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="medicamento.php">Medicamentos</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Recetas</a>
				</li>
				<li class="nav-item">
                    <a class="nav-link" href="logout.php">Cerrar Sesión</a> 
				</li>
			</ul>
		</div>
	</nav>';

    return $menuHtml;
    }


	public function get_list()
	{
		$d_new = "new/0";
		$d_new_final = base64_encode($d_new);
		$html = '
		<div class="container">
			<table class="table table-bordered table-striped table-dark mx-auto text-center my-5">
				<thead class="thead-dark">
					<tr>
						<th colspan="8" class="align-middle">Lista de Medicos</th>
					</tr>
					<tr>
						<th colspan="8"><a class="btn btn-warning" href="medicos.php?d=' . $d_new_final . '" role="button">Nuevo</a></th>
						
					</tr>
					<tr>
						<th class="align-middle">Nombre</th>
						<th class="align-middle">Especialidad</th>
						<th class="align-middle">Usuario</th>
						<th colspan="3" class="align-middle">Acciones</th>
					</tr>
				</thead>
				<tbody>';
		$sql = "SELECT m.IdMedico, m.Nombre, m.Especialidad, e.Descripcion, m.IdUsuario, u.Nombre AS Usuario
				FROM medicos AS m
				INNER JOIN especialidades AS e ON m.Especialidad = e.IdEsp
				INNER JOIN usuarios AS u ON m.IdUsuario = u.IdUsuario;";
		$res = $this->con->query($sql);
		// Sin codificar <td><a href="medicos.php?op=del&id=' . $row['id'] . '">Borrar</a></td>
		while ($row = $res->fetch_assoc()) {
			$d_del = "del/" . $row['IdMedico'];
			$d_del_final = base64_encode($d_del);
			$d_act = "act/" . $row['IdMedico'];
			$d_act_final = base64_encode($d_act);
			$d_det = "det/" . $row['IdMedico'];
			$d_det_final = base64_encode($d_det);
			$html .= '
			<tr>
				<td class="align-middle">' . $row['Nombre'] . '</td>
				<td class="align-middle">' . $row['Descripcion'] . '</td>
				<td class="align-middle">' . $row['Usuario'] . '</td>
				
				<td class="align-middle"> <a class="btn btn-danger" href="medicos.php?d=' . $d_del_final . '"> <i class="fas fa-trash"></i> BORRAR</a></td>
				<td class="align-middle"> <a class="btn btn-primary" href="medicos.php?d=' . $d_act_final . '"> <i class="fas fa-pencil-alt"></i> ACTUALIZAR</a></td>
				<td class="align-middle"> <a class="btn btn-info" href="medicos.php?d=' . $d_det_final . '"> <i class="fas fa-info-circle"></i> DETALLE</a></td>

		</tr>';
		}
		$html .= '</tbody>
		</table>
		<a class="btn btn-success" href="../front/index.html" role="button">HOME</a>	
	</div>';

		return $this->get_menu() . $html;
	}


	public function get_detail_medico($id)
	{
		$sql = "SELECT m.IdMedico, m.Nombre, m.Especialidad, e.Descripcion, m.IdUsuario, u.Nombre AS Usuario
				FROM medicos AS m
				INNER JOIN especialidades AS e ON m.Especialidad = e.IdEsp
				INNER JOIN usuarios AS u ON m.IdUsuario = u.IdUsuario
				WHERE IdMedico=$id;";
		$res = $this->con->query($sql);
		$row = $res->fetch_assoc();

		$num = $res->num_rows;

		//Si es que no existiese ningun registro debe desplegar un mensaje 
		//$mensaje = "tratar de eliminar el medico con id= ".$id;
		//echo $this->_message_error($mensaje);
		//y no debe desplegarse la tablas

		if ($num == 0) {
			$mensaje = "tratar de editar el medico con id= " . $id;
			echo $this->_message_error($mensaje);
		} else {
			$html = '
				<table border="1" align="center">
					<tr>
						<th colspan="2">DATOS DEL MEDICO</th>
					</tr>
					<tr>
						<td>Nombre: </td>
						<td>' . $row['Nombre'] . '</td>
					</tr>
					<tr>
						<td>Especialidad: </td>
						<td>' . $row['Descripcion'] . '</td>
					</tr>
					<tr>
						<td>Usuario: </td>
						<td>' . $row['Usuario'] . '</td>
					</tr>
					<tr>
						<th colspan="2"><a href="medicos.php">Regresar</a></th>
					</tr>																						
				</table>';

			return $html;
		}
	}


	public function delete_medico($id)
	{
		$sql = "DELETE FROM medicos WHERE IdMedico=$id;";
		if ($this->con->query($sql)) {
			echo $this->_message_ok("ELIMINÓ");
		} else {
			echo $this->_message_error("eliminar");
		}
	}

	//*************************************************************************


	private function _message_error($tipo)
	{
		$html = '
		<div class="container text-center">
		<div class="alert alert-danger" role="alert">
		Error al ' . $tipo . '. Favor contactar a .................... <br>
			<a class="btn btn-danger" href="medicos.php">Regresar</a>
		</div>
	</div>';
		return $html;
	}


	private function _message_ok($tipo)
	{
		$html = '
		<div class="container text-center">
			<div class="alert alert-success" role="alert">
				El registro se ' . $tipo . ' correctamente <br>
				<a class="btn btn-success" href="medicos.php">Regresar</a>
			</div>
		</div>';
		return $html;
	}

	//****************************************************************************	

} // FIN SCRPIT
