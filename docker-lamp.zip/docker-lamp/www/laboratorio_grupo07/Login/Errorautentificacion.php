<html>

<head>
	<meta charset="utf-8">
	<title>Sesiones en PHP</title>
</head>

<body>
	<table border=0 alingn="center" style="width:100%">
		<tr>
			<th colspan="3"> <a href="FormularioLogin.php">Regresar</a> </th>
		</tr>
		<tr>
			<td> <br> </td>
		</tr>
		<tr>
			<td> <br> </td>
		</tr>
		<tr>
			<th colspan="3">ERROR EN LA AUTENTIFICACION</th>
		</tr>
	</table>


</body>

</html>