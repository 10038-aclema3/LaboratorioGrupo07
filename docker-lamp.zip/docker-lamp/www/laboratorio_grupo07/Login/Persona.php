<?php
require_once(__DIR__ . "/../constantes.php");

class Persona
{
	private $idUsuario;
	private $usuario;
	private $contrasena;

	public function __construct()
	{
	}

	public function _construct($idUsuario, $usuario, $contrasena)
	{
		$this->idUsuario = $idUsuario;
		$this->usuario = $usuario;
		$this->contrasena = $contrasena;
	}

	public function getIdUsuario()
	{
		return $this->idUsuario;
	}

	public function setIdUsuario($idUsuario)
	{
		$this->idUsuario = $idUsuario;
	}

	public function getUsuario(): string
	{
		return $this->usuario;
	}

	public function setUsuario($usuario)
	{
		$this->usuario = $usuario;
	}

	public function getContrasena()
	{
		return $this->contrasena;
	}

	public function setContrasena($contrasena)
	{
		$this->contrasena = $contrasena;
	}

	public function getUsuarios(): array
	{
		$usuarios = [];

		$cn = $this->conectar();
		$sql = "SELECT Nombre, `Password` FROM usuarios;";
		$res = $cn->query($sql);

		while ($row = $res->fetch_assoc()) {
			$usuarios[$row['Nombre']] = $row;
		}

		return $usuarios;
	}

	public function getMedicos(): array
    {
        $medicos = [];

        $cn = $this->conectar();
        $sql = "SELECT Nombre, `Password` FROM usuarios WHERE Rol = 2;";
        $res = $cn->query($sql);

        while ($row = $res->fetch_assoc()) {
            $medicos[$row['Nombre']] = $row;
        }

        return $medicos;
    }

    public function getPacientes(): array
    {
        $pacientes = [];

        $cn = $this->conectar();
        $sql = "SELECT Nombre, `Password` FROM usuarios WHERE Rol = 3;";
        $res = $cn->query($sql);

        while ($row = $res->fetch_assoc()) {
            $pacientes[$row['Nombre']] = $row;
        }

        return $pacientes;
    }

    public function getAdministradores(): array
    {
        $administradores = [];

        $cn = $this->conectar();
        $sql = "SELECT Nombre, `Password` FROM usuarios WHERE Rol = 1;";
        $res = $cn->query($sql);

        while ($row = $res->fetch_assoc()) {
            $administradores[$row['Nombre']] = $row;
        }

        return $administradores;
    }
	public function validarLogin(): bool
	{
		$usuario = $this->getUsuario();
		$contrasena = $this->getContrasena();

		$cn = $this->conectar();
		$sql = "SELECT * FROM `usuarios` WHERE `Nombre`= '$usuario' and Password = '$contrasena'";
		$res = $cn->query($sql);
		$usuarioEncontrado = $res->fetch_assoc();

		return !empty($usuarioEncontrado);
	}

	
	public function obtenerRol($usuario): string
{
    $cn = $this->conectar();
    $sql = "SELECT u.IdUsuario, u.Nombre, r.Nombre AS Rol
            FROM usuarios u
            JOIN roles r ON u.Rol = r.IdRol
            WHERE u.Nombre = '$usuario';"; 
    $res = $cn->query($sql);
    $row = $res->fetch_assoc();

    return $row['Rol'] ?? 'Usuario'; 
}


	private function conectar()
	{
		$c = new mysqli(SERVER, USER, PASS, BD);

		if ($c->connect_errno) {
			die("Error de conexión: " . $c->connect_error);
		}

		$c->set_charset("utf8");
		return $c;
	}
}
