﻿<?php
ob_start();
session_start();

require_once(__DIR__.'/Persona.php');

$usuario = $_POST['usuario'];
$clave = $_POST['clave'];

$u = new Persona();
$u->setUsuario($usuario);
$u->setContrasena($clave);

$validacion = $u->validarLogin();
$rol = $u->obtenerRol($usuario);

if ($validacion) {
    $_SESSION['usuario'] = $usuario;
    $_SESSION['rol'] = $rol;

    // Redirige según el rol utilizando JavaScript
    echo '<script>';
    switch ($rol) {
        case 'Administrador':
            echo 'window.location.href = "../pacientes.php";';
            break;
        case 'Medico':
            echo 'window.location.href = "../consultas.php";';
            break;
        case 'Paciente':
            echo 'window.location.href = "../consultas.php";';
            break;
        default:
            echo 'window.location.href = "ErrorAutentificacion.php";';
    }
    echo '</script>';
} else {
    echo '<script>window.location.href = "ErrorAutentificacion.php";</script>';
}

ob_end_flush();
?>
